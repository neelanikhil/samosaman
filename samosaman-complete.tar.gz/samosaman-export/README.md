# SamosaMan - Inventory & Sales Management System

Complete codebase for the SamosaMan inventory and sales management application.

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Set Up Environment Variables
Copy `.env.example` to `.env` and configure:
```bash
cp .env.example .env
```

Required variables:
- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - JWT secret key
- `ADMIN_EMAIL` - Admin email address
- `SENDGRID_API_KEY` - SendGrid API key (optional, for emails)

### 3. Set Up Database
```bash
npm run db:push
```

### 4. Run Development Server
```bash
npm run dev
```

App will be available at `http://localhost:5000`

## 📁 Project Structure

```
samosaman/
├── client/              # Frontend (React + Vite + Tailwind)
├── server/              # Backend (Express + PostgreSQL)
├── shared/              # Shared types and schemas
└── Configuration files
```

## 🔑 Default Credentials

**Admin:**
- Email: neelanikhil997@gmail.com
- Password: admin123

**Employee:** 
- Sign up at `/signup` (requires admin approval)

## 🛠️ Tech Stack

**Frontend:**
- React 18 + TypeScript
- Vite
- Tailwind CSS + shadcn/ui
- TanStack Query
- Wouter (routing)

**Backend:**
- Express.js
- PostgreSQL (Neon)
- Drizzle ORM
- JWT Authentication
- SendGrid (email)

## 📧 Email Setup (Optional)

See `SENDGRID_SETUP.md` for detailed instructions on setting up SendGrid dynamic templates.

## 🚢 Deployment

### Build for Production
```bash
npm run build
npm start
```

### Environment Variables for Production
Make sure to set all environment variables in your production environment.

## 📊 Features

- **Role-based Authentication** (Admin/Employee)
- **Inventory Management** (8 samosa types)
- **Daily Sales Reports** with draft/submit workflow
- **Analytics Dashboard** with charts and metrics
- **Employee Approval System**
- **Email Notifications** (SendGrid)
- **Low Inventory Alerts**

## 📝 Database Tables

- `users` - User accounts
- `employee_permissions` - Employee approvals
- `inventory` - Samosa inventory
- `markets` - Market locations
- `daily_reports` - Sales reports

## 🔗 API Endpoints

### Authentication
- `POST /api/auth/signup` - Employee registration
- `POST /api/auth/login` - Login

### Admin
- `GET /api/admin/employees` - List employees
- `PATCH /api/admin/approve/:id` - Approve employee
- `DELETE /api/admin/employees/:id` - Delete employee

### Reports
- `POST /api/reports` - Create/submit report
- `PATCH /api/reports/:id` - Update report
- `GET /api/reports` - List reports

### Inventory
- `GET /api/inventory` - Get inventory
- `POST /api/inventory/add` - Add inventory

### Analytics
- `GET /api/dashboard-data` - Dashboard analytics

## 📄 License

MIT

## 💡 Support

For issues or questions, refer to `replit.md` for detailed documentation.
