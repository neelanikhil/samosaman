# SamosaMan - Inventory & Sales Management System

## Overview

SamosaMan is a comprehensive inventory and sales management system designed for a samosa business. The application provides role-based access control for Admin and Employee users, enabling efficient tracking of inventory, daily sales reports, and business analytics across multiple market locations.

The system manages 8 different samosa types (Apple, Veggie, Punjabi, Vermont Spicy Potato, Spicy Chicken, Chicken & Cheese, Steak & Cheese, Steak & Potato) in fixed order and provides tools for inventory management, sales reporting, and market performance analysis.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

### Database Migration to PostgreSQL (October 2025)
- **Completed**: Full migration from in-memory storage to PostgreSQL
- **What Changed**: 
  - All data now persists in Neon PostgreSQL database
  - Migrated existing data: 10 inventory items, 4 markets, 12 reports
  - Created PgStorage implementation using Drizzle ORM
  - Auto-creates default Admin and Employee users on startup
- **Benefits**: Production-ready data persistence, concurrent access support, data durability

### Role-Based Authentication System (October 2025)
- **Completed**: Full JWT-based authentication with role verification
- **Database Schema Updates**:
  - Added `email`, `name`, `is_active`, `created_at` fields to users table
  - Created `employee_permissions` table for approval tracking
  - Admin email set to neelanikhil997@gmail.com (configured in environment)
- **Authentication Features**:
  - JWT token-based authentication with 7-day expiration
  - Bcrypt password hashing for secure storage
  - Role-based access control (Admin vs Employee)
  - Employee approval workflow - new employees are inactive until admin approves
  - Admin-only routes protected by email verification
- **Authentication UI Flow**:
  - Landing page (/) - Role selection with "Login as Admin" and "Login as Employee" buttons
  - Login page (/login) - "Welcome Back" design with email/password fields and signup link
  - Signup page (/signup) - Employee registration with name, username, email, password fields
  - SamosaMan branded logo across all auth pages
  - Role-based redirects: Admin → /admin, Employee → /employee
- **Employee Management Tab** (Admin Portal):
  - New "Employees" tab in admin dashboard
  - View ALL employees (both pending and active) with status badges
  - Status badges: "Pending" (amber) for unapproved, "Active" (green) for approved employees
  - Employee count summary shows "X active, Y pending approval"
  - One-click approval button for pending employees
  - Delete button with confirmation dialog for all employees (active or pending)
  - Cascade deletion: Removes employee_permissions first, then user record
  - Shows employee details: name, username, email, status
  - Real-time updates after approval/deletion via query invalidation
  - **Note**: Employees can only sign up via /signup page - admin cannot create employees
- **Email Notifications** (SendGrid):
  - Welcome email sent on employee registration
  - Approval email sent when admin activates employee account
  - Admin receives email when employee saves draft report
  - Admin receives email when employee submits report
  - Admin receives email when inventory falls below thresholds (APP<150, VEG/PJB/VSP/STP<225, SCH/CHC/STC<300)
  - Configured with SENDGRID_API_KEY environment variable
- **SendGrid Dynamic Templates** (October 2025):
  - **Implemented**: Full support for SendGrid dynamic templates with intelligent fallback
  - **Smart Fallback**: Uses dynamic templates if configured, automatically falls back to HTML emails if not
  - **Template Types** (5 templates supported):
    - SG_TEMPLATE_WELCOME - Welcome email with employeeName, username, appUrl
    - SG_TEMPLATE_APPROVAL - Approval email with employeeName, loginUrl, appUrl
    - SG_TEMPLATE_LOW_INV - Low inventory alert with inventoryList array, dashboardUrl
    - SG_TEMPLATE_REPORT_SUBMITTED - Report submitted with employeeName, marketName, reportDate, status, dashboardUrl
    - SG_TEMPLATE_DRAFT_SAVED - Draft saved (same fields as report submitted)
  - **Environment Variables**: FROM_EMAIL, ADMIN_EMAIL, APP_URL, SG_TEMPLATE_* (all optional except API key)
  - **Debug Endpoint**: GET /api/debug/send-test-email (admin auth required, sends to ADMIN_EMAIL only)
  - **Documentation**: See SENDGRID_SETUP.md and .env.example for complete setup guide
  - **Security**: Debug endpoint protected by verifyToken and verifyAdmin, no arbitrary recipients allowed
- **API Endpoints**:
  - POST /api/auth/signup - Employee registration (requires username, email, password, name)
  - POST /api/auth/login - Email/password login with JWT token generation
  - GET /api/admin/employees - List all employees (pending + active, admin only)
  - PATCH /api/admin/approve/:id - Approve employee and send notification (admin only)
  - DELETE /api/admin/employees/:id - Delete employee with cascade permission cleanup (admin only)
- **Security**: Admin access requires both 'admin' role AND matching ADMIN_EMAIL environment variable
- **Credentials**: Admin login - email: neelanikhil997@gmail.com, password: admin123

### Draft Report Editing (October 2025)
- Employees can now edit saved draft reports
- Draft reports show amber "Draft" badge with Edit button
- Submitted reports show green "Submitted" badge (cannot be edited)
- Form properly resets after save/submit operations

### Samosa Types & Form Enhancements (October 2025)
- **Samosa Types**: System manages 8 types for inventory
  - Fixed order for employee form: APP, VEG, PJB, VSP, SCH, CHC, STC, STP
  - CCM (Chicken Curry), CPM (Chickpea), and RICE (Top of the Rice) moved to Additional Items
- **Additional Items Section**: Expanded to include 4 items with Taken/Return dropdowns
  - CCM (Chicken Curry), CPM (Chickpea), RICE (Top of the Rice), SSS
  - Dropdown options: 1/4 (0.25), 1/2 (0.5), 3/4 (0.75), 1, 2, 3, 4, 5
- **Note Field**: Added optional textarea for employee observations/notes on reports
- **Form Inputs**: Removed default 0 values - inputs now start blank for cleaner UX

### Admin Dashboard with Analytics (October 2025)
- **Date Range Picker**: Custom date range selection for filtering analytics (defaults to last 30 days)
- **Analytics Cards**: 
  - Total Revenue: (Cash + Mobile + Venmo) - Expenses (excludes tips)
  - Total Samosas Sold: Calculated from submitted reports
  - Top Market: Shows market with most samosas sold (replaced Total Reports card)
- **Visual Charts**:
  - Pie Chart: Sales distribution by samosa type with shortcut names and percentages (e.g., "APP 38%") - filters out CCM/CPM and 0% categories
  - Bar Chart: Total revenue by market with custom tooltip showing revenue amount, samosas count, date, and day
- **API Endpoint**: GET /api/dashboard-data with startDate/endDate query parameters
  - Returns topMarket data (market with most samosas sold)
  - Returns marketSales with revenue, samosas, date, and day for each market
- **Bug Fixes**: Corrected date field usage (uses 'date' instead of non-existent 'reportDate')

## System Architecture

### Frontend Architecture

**Framework & Build System**
- React 18+ with TypeScript for type-safe component development
- Vite as the build tool and development server with HMR (Hot Module Replacement)
- React Router for client-side routing (implied by SPA structure)

**UI Component System**
- shadcn/ui components built on Radix UI primitives for accessible, customizable components
- Material Design principles for information-dense business application UX
- Tailwind CSS for utility-first styling with custom design tokens
- Class Variance Authority (CVA) for component variant management

**State Management & Data Fetching**
- TanStack Query (React Query) for server state management, caching, and data synchronization
- Local React state (useState) for UI state management
- Custom query client configuration with disabled refetching and infinite stale time

**Design System**
- Light/Dark theme support with ThemeProvider context
- Custom color palette: Deep Teal primary (#27 65% 47%), Warm Amber secondary (#35 85% 55%)
- Typography: Inter font family for readability, JetBrains Mono for numeric displays
- Consistent spacing system using Tailwind units (2, 4, 8, 12, 16, 20)

### Backend Architecture

**Server Framework**
- Express.js for REST API endpoints
- HTTP server setup with middleware for JSON parsing and URL encoding
- Custom logging middleware for API request/response tracking

**Data Storage Strategy**
- PostgreSQL database using Neon serverless driver for production data persistence
- PgStorage implementation using Drizzle ORM for type-safe database operations
- All data persists in relational database tables (users, inventory, markets, daily_reports)
- Auto-initialization of default users (Admin/Employee) on server startup

**ORM & Database Schema**
- Drizzle ORM with PostgreSQL adapter
- Schema definitions: users, inventory, markets, dailyReports tables
- Zod schema validation using drizzle-zod for runtime type safety
- UUID primary keys with automatic generation

**API Design**
- RESTful endpoints for report management:
  - POST /api/reports - Submit daily reports (auto-deducts inventory on submit)
  - PATCH /api/reports/:id - Update report (for draft editing)
  - GET /api/reports - Retrieve all reports  
  - GET /api/reports/:id - Get specific report by ID
- Analytics endpoints:
  - GET /api/dashboard-data?startDate=X&endDate=Y - Get filtered analytics with revenue, sales, charts data
  - GET /api/dashboard/stats?period=weekly|monthly - Legacy stats endpoint
- Inventory and markets endpoints:
  - GET /api/inventory - Get inventory levels
  - POST /api/inventory/add - Add inventory quantities
  - GET /api/markets - Get all markets
  - POST /api/markets - Create new market
- Structured error handling with appropriate HTTP status codes

### Data Models

**Users**
- Role-based access: "admin" or "employee"
- Username/password authentication (passwords stored as hashed values)

**Inventory**
- Weekly inventory tracking by samosa type
- Quantity management for 8 samosa varieties (APP, VEG, PJB, VSP, SCH, CHC, STC, STP)
- Auto-deducts sold, gift, waste, and eat quantities when reports are submitted

**Daily Reports**
- Comprehensive sales data including market name, employee, date, shift times
- Samosa-specific data (taken, RNF, RF, gift, waste, eat) stored as JSON for 8 types
- Additional items with Taken/Return dropdowns stored in individual columns:
  - CCM (Chicken Curry): ccmTaken, ccmReturn
  - CPM (Chickpea): cpmTaken, cpmReturn
  - RICE (Top of the Rice): riceTaken, riceReturn
  - SSS: sssTaken, sssReturn
  - Full/Half Meals also tracked separately
- Financial data: cash sales, mobile sales, venmo sales, expenses, tips (online/offline)
- Optional note field for employee observations
- Status: 'draft' (editable) or 'submitted' (locked)
- Database fields use snake_case (e.g., 'date' not 'reportDate')

### Development Tools & Configuration

**TypeScript Configuration**
- Strict mode enabled for maximum type safety
- Path aliases for clean imports (@/, @shared/, @assets/)
- ESNext module system with bundler resolution
- Incremental compilation for faster builds

**Build Pipeline**
- Client: Vite build outputting to dist/public
- Server: esbuild bundling to dist/index.js with ESM format
- Separate dev and production environments

## External Dependencies

### Core Runtime Dependencies

**Database & ORM**
- `drizzle-orm` - Type-safe ORM for database operations
- `@neondatabase/serverless` - Neon serverless PostgreSQL driver
- `drizzle-zod` - Zod schema generation from Drizzle schemas
- `connect-pg-simple` - PostgreSQL session store

**UI Framework & Components**
- React 18+ ecosystem (react, react-dom)
- `@radix-ui/*` - 20+ accessible component primitives (dialogs, dropdowns, tooltips, etc.)
- `recharts` - Data visualization and charting library
- `lucide-react` - Icon library
- `cmdk` - Command palette component

**Forms & Validation**
- `react-hook-form` - Form state management
- `@hookform/resolvers` - Validation resolvers
- `zod` - Schema validation

**Styling & Utilities**
- `tailwindcss` - Utility-first CSS framework
- `tailwind-merge` & `clsx` - Conditional className utilities
- `class-variance-authority` - Component variant management
- `date-fns` - Date manipulation utilities

**State Management**
- `@tanstack/react-query` - Async state and caching

**Development & Build Tools**
- `vite` - Build tool and dev server
- `@vitejs/plugin-react` - React support for Vite
- TypeScript compiler and type definitions
- esbuild - Server bundling
- PostCSS & Autoprefixer - CSS processing

### Third-Party Services & APIs

**Database Infrastructure**
- Neon Serverless PostgreSQL - Production database hosting with automatic scaling
- All application data persists in PostgreSQL database tables

Currently, no external API integrations for third-party services (payment processing, SMS, etc.).

### Development-Specific Dependencies

- `@replit/vite-plugin-runtime-error-modal` - Error overlay for Replit
- `@replit/vite-plugin-cartographer` - Replit-specific tooling
- `@replit/vite-plugin-dev-banner` - Development environment banner

### Font Resources

Google Fonts CDN integration for typography:
- Inter (primary UI font)
- DM Sans
- Fira Code / Geist Mono (monospace)
- Architects Daughter (decorative)