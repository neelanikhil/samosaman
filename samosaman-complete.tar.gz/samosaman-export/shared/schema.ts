import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, decimal, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const SAMOSA_TYPES = {
  APP: "Apple",
  VEG: "Veggie",
  PJB: "Punjabi",
  VSP: "Vermont Spicy Potato",
  SCH: "Spicy Chicken",
  CHC: "Chicken & Cheese",
  STC: "Steak & Cheese",
  STP: "Steak & Potato",
  CCM: "Chicken Curry",
  CPM: "Chickpea",
  RICE: "Top of the Rice",
} as const;

// Fixed display order for employee portal (CCM, CPM, RICE removed from form display)
export const SAMOSA_ORDER: (keyof typeof SAMOSA_TYPES)[] = [
  "APP", "VEG", "PJB", "VSP", "SCH", "CHC", "STC", "STP"
];

export type SamosaType = keyof typeof SAMOSA_TYPES;

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  name: text("name"),
  email: text("email").unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("employee"),
  isActive: boolean("is_active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const employeePermissions = pgTable("employee_permissions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  employeeId: varchar("employee_id").notNull().references(() => users.id),
  approvedByAdmin: boolean("approved_by_admin").notNull().default(false),
  approvedDate: timestamp("approved_date"),
});

export const inventory = pgTable("inventory", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  samosaType: text("samosa_type").notNull(),
  initialQuantity: integer("initial_quantity").notNull().default(0),
  sold: integer("sold").notNull().default(0),
  gift: integer("gift").notNull().default(0),
  waste: integer("waste").notNull().default(0),
  eat: integer("eat").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const markets = pgTable("markets", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const dailyReports = pgTable("daily_reports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  marketName: text("market_name").notNull(),
  employeeName: text("employee_name").notNull(),
  date: text("date").notNull(),
  day: text("day"),
  shiftStart: text("shift_start"),
  shiftEnd: text("shift_end"),
  samosaData: text("samosa_data"),
  additionalItems: text("additional_items"),
  fullMealsQty: text("full_meals_qty"),
  fullMealPrice: text("full_meal_price"),
  halfMealsQty: text("half_meals_qty"),
  halfMealPrice: text("half_meal_price"),
  ccmTaken: text("ccm_taken"),
  ccmReturn: text("ccm_return"),
  cpmTaken: text("cpm_taken"),
  cpmReturn: text("cpm_return"),
  riceTaken: text("rice_taken"),
  riceReturn: text("rice_return"),
  sssTaken: text("sss_taken"),
  sssReturn: text("sss_return"),
  expenses: text("expenses"),
  cashSales: text("cash_sales"),
  mobileSales: text("mobile_sales"),
  venmoSales: text("venmo_sales"),
  tipsOnline: text("tips_online"),
  tipsOffline: text("tips_offline"),
  totalSamosaSales: decimal("total_samosa_sales", { precision: 10, scale: 2 }),
  totalMealsSales: decimal("total_meals_sales", { precision: 10, scale: 2 }),
  totalSales: decimal("total_sales", { precision: 10, scale: 2 }),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }),
  difference: decimal("difference", { precision: 10, scale: 2 }),
  status: text("status").notNull().default("draft"),
  note: text("note"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertEmployeePermissionSchema = createInsertSchema(employeePermissions).omit({
  id: true,
});

export const insertInventorySchema = createInsertSchema(inventory).omit({
  id: true,
  updatedAt: true,
});

export const insertMarketSchema = createInsertSchema(markets).omit({
  id: true,
  createdAt: true,
});

export const insertDailyReportSchema = createInsertSchema(dailyReports).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type EmployeePermission = typeof employeePermissions.$inferSelect;
export type InsertEmployeePermission = z.infer<typeof insertEmployeePermissionSchema>;
export type Inventory = typeof inventory.$inferSelect;
export type Market = typeof markets.$inferSelect;
export type DailyReport = typeof dailyReports.$inferSelect;
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type InsertMarket = z.infer<typeof insertMarketSchema>;
export type InsertDailyReport = z.infer<typeof insertDailyReportSchema>;

export interface SamosaReportData {
  rnf: number;
  rf: number;
  giftWasteEat: number;
  sold: number;
}

export interface SamosaTakenData {
  taken: number;
}
