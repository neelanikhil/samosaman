import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, User } from "lucide-react";
import logoImage from "@assets/image_1760146274837.png";

export function LandingPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#FAF8F4" }}>
      <Card className="w-full max-w-md border-0 shadow-lg">
        <CardContent className="pt-12 pb-8 px-8">
          <div className="space-y-8">
            <div className="text-center space-y-4">
              <img src={logoImage} alt="SamosaMan Logo" className="h-32 w-auto mx-auto" />
              <p className="text-lg text-muted-foreground">Inventory & Sales Management</p>
            </div>

            <div className="space-y-4">
              <Button
                onClick={() => setLocation("/login?role=admin")}
                className="w-full h-14 text-lg"
                style={{ backgroundColor: "#C13B3A", color: "white" }}
                data-testid="button-admin-login"
              >
                <Shield className="mr-2 h-5 w-5" />
                Login as Admin
              </Button>

              <Button
                onClick={() => setLocation("/login?role=employee")}
                className="w-full h-14 text-lg"
                style={{ backgroundColor: "#E89A3C", color: "white" }}
                data-testid="button-employee-login"
              >
                <User className="mr-2 h-5 w-5" />
                Login as Employee
              </Button>
            </div>

            <div className="text-center text-sm text-muted-foreground pt-4">
              © 2025 SamosaMan, Inc.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
