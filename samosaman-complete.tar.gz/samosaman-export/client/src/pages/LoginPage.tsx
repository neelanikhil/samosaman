import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import logoImage from "@assets/image_1760146274837.png";
import type { User as AuthUser } from "@/lib/auth";

interface LoginPageProps {
  onLoginSuccess: (token: string, user: AuthUser) => void;
}

export function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      toast({
        title: "Error",
        description: "Please enter both email and password",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Login failed");
      }

      toast({
        title: "Success",
        description: `Welcome back, ${data.user.name || data.user.username}!`,
      });

      onLoginSuccess(data.token, data.user);
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#FAF8F4" }}>
      <Card className="w-full max-w-md border-0 shadow-lg relative">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation("/")}
          className="absolute left-4 top-4"
          data-testid="button-back"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back
        </Button>
        
        <CardContent className="pt-16 pb-8 px-8">
          <div className="space-y-6">
            <div className="text-center space-y-3">
              <img src={logoImage} alt="SamosaMan Logo" className="h-28 w-auto mx-auto" />
              <h1 className="text-3xl font-bold">Welcome Back</h1>
              <p className="text-muted-foreground">Inventory & Sales Management</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="name@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                  data-testid="input-email"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={isLoading}
                  data-testid="input-password"
                  required
                />
              </div>
              <Button 
                type="submit" 
                className="w-full h-12" 
                disabled={isLoading}
                style={{ backgroundColor: "#E89A3C", color: "white" }}
                data-testid="button-login"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging in...
                  </>
                ) : (
                  "Login"
                )}
              </Button>
            </form>

            <div className="text-center">
              <button
                type="button"
                onClick={() => setLocation("/signup")}
                className="text-sm text-primary hover:underline"
                data-testid="link-signup"
              >
                Don't have an account? Sign up
              </button>
            </div>

            <div className="text-center text-sm text-muted-foreground pt-2">
              © 2025 SamosaMan, Inc.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
