import { useState, useEffect } from "react";
import { Router, Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { ThemeToggle } from "@/components/ThemeToggle";
import { LandingPage } from "@/pages/LandingPage";
import { LoginPage } from "@/pages/LoginPage";
import { SignupPage } from "@/pages/SignupPage";
import { DailyReportForm } from "@/components/DailyReportForm";
import { EmployeeSavedReports } from "@/components/EmployeeSavedReports";
import { AdminDashboard } from "@/components/AdminDashboard";
import { AdminInventoryAdd } from "@/components/AdminInventoryAdd";
import { AdminReportsView } from "@/components/AdminReportsView";
import { AdminEmployeeManagement } from "@/components/AdminEmployeeManagement";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { BarChart3, Package, FileText, LogOut, FilePlus, Users } from "lucide-react";
import logoImage from "@assets/image_1759984310092.png";
import type { DailyReport } from "@shared/schema";
import { getAuth, saveAuth, clearAuth, type User } from "@/lib/auth";

function AppContent() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState("new-report");
  const [draftToEdit, setDraftToEdit] = useState<DailyReport | null>(null);
  const [, setLocation] = useLocation();

  // Check for existing auth on mount
  useEffect(() => {
    const { user } = getAuth();
    if (user) {
      setCurrentUser(user);
    }
  }, []);

  const handleLoginSuccess = (token: string, user: User) => {
    saveAuth(token, user);
    setCurrentUser(user);
    // Redirect based on role
    setLocation(user.role === "admin" ? "/admin" : "/employee");
  };

  const handleLogout = () => {
    clearAuth();
    setCurrentUser(null);
    setLocation("/");
  };

  const handleEditDraft = (report: DailyReport) => {
    setDraftToEdit(report);
    setActiveTab("new-report");
  };

  // Public routes (no auth required)
  if (!currentUser) {
    return (
      <Switch>
        <Route path="/" component={LandingPage} />
        <Route path="/login">
          <LoginPage onLoginSuccess={handleLoginSuccess} />
        </Route>
        <Route path="/signup" component={SignupPage} />
        <Route>
          {/* Redirect to landing if no match */}
          <LandingPage />
        </Route>
      </Switch>
    );
  }

  // Protected routes (auth required)
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img src={logoImage} alt="SamosaMan" className="h-10" />
            <div>
              <h1 className="text-lg font-bold">SamosaMan</h1>
              <p className="text-xs text-muted-foreground">
                {currentUser.role === "admin" ? "Admin Dashboard" : "Employee Portal"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="outline" onClick={handleLogout} data-testid="button-logout" className="gap-2">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <Switch>
          {currentUser.role === "employee" ? (
            <>
              <Route path="/employee">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold mb-2">Employee Portal</h2>
                    <p className="text-muted-foreground">Submit daily reports and view your submissions</p>
                  </div>
                  
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="new-report" data-testid="tab-new-report" className="gap-2">
                        <FilePlus className="h-4 w-4" />
                        New Report
                      </TabsTrigger>
                      <TabsTrigger value="saved-reports" data-testid="tab-saved-reports" className="gap-2">
                        <FileText className="h-4 w-4" />
                        My Reports
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="new-report" className="space-y-4">
                      <DailyReportForm draftReport={draftToEdit} onClearDraft={() => setDraftToEdit(null)} />
                    </TabsContent>

                    <TabsContent value="saved-reports" className="space-y-4">
                      <EmployeeSavedReports onEditDraft={handleEditDraft} />
                    </TabsContent>
                  </Tabs>
                </div>
              </Route>
              <Route>
                {/* Redirect to employee portal if employee tries to access other routes */}
                {(() => { setLocation("/employee"); return null; })()}
              </Route>
            </>
          ) : (
            <>
              <Route path="/admin">
                <div className="max-w-7xl mx-auto">
                  <div className="mb-6">
                    <h2 className="text-2xl font-bold mb-2">Admin Dashboard</h2>
                    <p className="text-muted-foreground">Manage inventory, view analytics, and access reports</p>
                  </div>
                  
                  <Tabs defaultValue="dashboard" className="space-y-4">
                    <TabsList className="grid w-full grid-cols-4">
                      <TabsTrigger value="dashboard" data-testid="tab-dashboard" className="gap-2">
                        <BarChart3 className="h-4 w-4" />
                        Dashboard
                      </TabsTrigger>
                      <TabsTrigger value="inventory" data-testid="tab-inventory" className="gap-2">
                        <Package className="h-4 w-4" />
                        Add Inventory
                      </TabsTrigger>
                      <TabsTrigger value="reports" data-testid="tab-reports" className="gap-2">
                        <FileText className="h-4 w-4" />
                        Reports
                      </TabsTrigger>
                      <TabsTrigger value="employees" data-testid="tab-employees" className="gap-2">
                        <Users className="h-4 w-4" />
                        Employees
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="dashboard" className="space-y-4">
                      <AdminDashboard />
                    </TabsContent>

                    <TabsContent value="inventory" className="space-y-4">
                      <AdminInventoryAdd />
                    </TabsContent>

                    <TabsContent value="reports" className="space-y-4">
                      <AdminReportsView />
                    </TabsContent>

                    <TabsContent value="employees" className="space-y-4">
                      <AdminEmployeeManagement />
                    </TabsContent>
                  </Tabs>
                </div>
              </Route>
              <Route>
                {/* Redirect to admin dashboard if admin tries to access other routes */}
                {(() => { setLocation("/admin"); return null; })()}
              </Route>
            </>
          )}
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <Router>
            <AppContent />
          </Router>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
