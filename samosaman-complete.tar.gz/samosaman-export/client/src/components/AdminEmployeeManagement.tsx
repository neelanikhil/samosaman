import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Mail, User, Trash2, UserCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Employee {
  id: string;
  username: string;
  email: string;
  name: string;
  isActive: boolean;
  createdAt: string;
}

export function AdminEmployeeManagement() {
  const { toast } = useToast();

  const { data: employees, isLoading } = useQuery<Employee[]>({
    queryKey: ['/api/admin/employees'],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/admin/employees");
      return response.json();
    },
  });

  const approveMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      return await apiRequest("PATCH", `/api/admin/approve/${employeeId}`);
    },
    onSuccess: async (response, employeeId) => {
      const data = await response.json();
      toast({
        title: "Employee Approved",
        description: `${data.user.name} has been approved and can now login.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/employees'] });
    },
    onError: (error: any) => {
      toast({
        title: "Approval Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      return await apiRequest("DELETE", `/api/admin/employees/${employeeId}`);
    },
    onSuccess: async () => {
      toast({
        title: "Employee Deleted",
        description: "Employee has been removed from the system.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/employees'] });
    },
    onError: (error: any) => {
      toast({
        title: "Deletion Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleApprove = (employeeId: string) => {
    approveMutation.mutate(employeeId);
  };

  const handleDelete = (employeeId: string) => {
    deleteMutation.mutate(employeeId);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">Loading employees...</p>
        </CardContent>
      </Card>
    );
  }

  const pendingCount = employees?.filter(e => !e.isActive).length || 0;
  const activeCount = employees?.filter(e => e.isActive).length || 0;

  if (!employees || employees.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Employee Management
          </CardTitle>
          <CardDescription>Manage employee accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <User className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-lg font-medium">No Employees</p>
            <p className="text-sm text-muted-foreground mt-1">
              New employees will appear here after signing up
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Employee Management
        </CardTitle>
        <CardDescription>
          {activeCount} active, {pendingCount} pending approval
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {employees.map((employee) => (
            <div
              key={employee.id}
              className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
              data-testid={`employee-${employee.id}`}
            >
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-medium">{employee.name}</h4>
                  {employee.isActive ? (
                    <Badge variant="default" className="gap-1">
                      <UserCheck className="h-3 w-3" />
                      Active
                    </Badge>
                  ) : (
                    <Badge variant="secondary" className="gap-1">
                      <Clock className="h-3 w-3" />
                      Pending
                    </Badge>
                  )}
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    <span>{employee.username}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Mail className="h-3 w-3" />
                    <span>{employee.email}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {!employee.isActive && (
                  <Button
                    onClick={() => handleApprove(employee.id)}
                    disabled={approveMutation.isPending}
                    className="gap-2"
                    data-testid={`button-approve-${employee.id}`}
                  >
                    <CheckCircle className="h-4 w-4" />
                    Approve
                  </Button>
                )}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button
                      variant="destructive"
                      size="icon"
                      disabled={deleteMutation.isPending}
                      data-testid={`button-delete-${employee.id}`}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Delete Employee?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to delete {employee.name}? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction
                        onClick={() => handleDelete(employee.id)}
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Delete
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
