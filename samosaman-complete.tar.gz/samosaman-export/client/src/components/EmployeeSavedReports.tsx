import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Calendar, DollarSign, Eye, Edit } from "lucide-react";
import type { DailyReport } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useState } from "react";

interface EmployeeSavedReportsProps {
  onEditDraft?: (report: DailyReport) => void;
}

export function EmployeeSavedReports({ onEditDraft }: EmployeeSavedReportsProps) {
  const { data: reports, isLoading } = useQuery<DailyReport[]>({
    queryKey: ['/api/reports'],
  });

  const [selectedReport, setSelectedReport] = useState<DailyReport | null>(null);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Submitted Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Loading reports...</p>
        </CardContent>
      </Card>
    );
  }

  if (!reports || reports.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>My Submitted Reports</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">No reports submitted yet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            My Submitted Reports
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Day</TableHead>
                  <TableHead>Market</TableHead>
                  <TableHead>Employee</TableHead>
                  <TableHead className="text-right">Total Amount</TableHead>
                  <TableHead className="text-right">Difference</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.map((report) => (
                  <TableRow key={report.id} data-testid={`row-report-${report.id}`}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        {report.date}
                      </div>
                    </TableCell>
                    <TableCell>{report.day || '-'}</TableCell>
                    <TableCell>{report.marketName}</TableCell>
                    <TableCell>{report.employeeName}</TableCell>
                    <TableCell className="text-right font-mono">
                      <div className="flex items-center justify-end gap-1">
                        <DollarSign className="h-4 w-4 text-muted-foreground" />
                        {report.totalAmount || '0.00'}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono">
                      <span className={
                        parseFloat(report.difference || '0') < 0 
                          ? 'text-destructive font-semibold' 
                          : 'text-chart-3 font-semibold'
                      }>
                        ${report.difference || '0.00'}
                      </span>
                    </TableCell>
                    <TableCell>
                      {report.status === 'draft' ? (
                        <Badge variant="outline" className="bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border-amber-300 dark:border-amber-500/30">
                          Draft
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 border-green-300 dark:border-green-500/30">
                          Submitted
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        {report.status === 'draft' && onEditDraft && (
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => onEditDraft(report)}
                            data-testid={`button-edit-${report.id}`}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        <Button 
                          size="sm" 
                          variant="ghost"
                          onClick={() => setSelectedReport(report)}
                          data-testid={`button-view-${report.id}`}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Report Details</DialogTitle>
          </DialogHeader>
          {selectedReport && <ReportDetailsView report={selectedReport} />}
        </DialogContent>
      </Dialog>
    </>
  );
}

function ReportDetailsView({ report }: { report: DailyReport }) {
  const samosaData = report.samosaData ? JSON.parse(report.samosaData) : {};
  const additionalItems = report.additionalItems ? JSON.parse(report.additionalItems) : {};

  const parseNum = (val: string | number) => parseFloat(String(val)) || 0;

  const calculateSold = (data: any) => {
    return Math.max(0, 
      parseNum(data.taken) - parseNum(data.rnf) - parseNum(data.rf) - 
      parseNum(data.gift) - parseNum(data.waste) - parseNum(data.eat)
    );
  };

  const calculateSales = (data: any) => {
    return calculateSold(data) * 4;
  };

  return (
    <div className="space-y-6">
      {/* Basic Information */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Market</p>
          <p className="font-medium" data-testid="text-market">{report.marketName}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Date</p>
          <p className="font-medium" data-testid="text-date">{report.date}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Day</p>
          <p className="font-medium" data-testid="text-day">{report.day || '-'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Employee</p>
          <p className="font-medium" data-testid="text-employee">{report.employeeName}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Shift Start</p>
          <p className="font-medium" data-testid="text-shift-start">{report.shiftStart || '-'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Shift End</p>
          <p className="font-medium" data-testid="text-shift-end">{report.shiftEnd || '-'}</p>
        </div>
      </div>

      {/* Samosa Sales Data */}
      {Object.keys(samosaData).length > 0 && (
        <div>
          <h3 className="font-semibold mb-3">Samosa Sales</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Taken</TableHead>
                  <TableHead className="text-right">RNF</TableHead>
                  <TableHead className="text-right">RF</TableHead>
                  <TableHead className="text-right">Gift</TableHead>
                  <TableHead className="text-right">Waste</TableHead>
                  <TableHead className="text-right">Eat</TableHead>
                  <TableHead className="text-right">Sold</TableHead>
                  <TableHead className="text-right">Sales</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(samosaData).map(([type, data]: [string, any]) => {
                  const sold = calculateSold(data);
                  const sales = calculateSales(data);
                  return (
                    <TableRow key={type}>
                      <TableCell className="font-medium">{type}</TableCell>
                      <TableCell className="text-right">{data.taken || 0}</TableCell>
                      <TableCell className="text-right">{data.rnf || 0}</TableCell>
                      <TableCell className="text-right">{data.rf || 0}</TableCell>
                      <TableCell className="text-right">{data.gift || 0}</TableCell>
                      <TableCell className="text-right">{data.waste || 0}</TableCell>
                      <TableCell className="text-right">{data.eat || 0}</TableCell>
                      <TableCell className="text-right font-semibold">{sold}</TableCell>
                      <TableCell className="text-right font-mono">${sales.toFixed(2)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Meals Section */}
      <div>
        <h3 className="font-semibold mb-3">Meals</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Full Meals Qty</p>
            <p className="font-medium">{report.fullMealsQty || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Full Meal Price</p>
            <p className="font-medium font-mono">${report.fullMealPrice || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Half Meals Qty</p>
            <p className="font-medium">{report.halfMealsQty || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Half Meal Price</p>
            <p className="font-medium font-mono">${report.halfMealPrice || '0.00'}</p>
          </div>
        </div>
      </div>

      {/* Additional Items */}
      {Object.keys(additionalItems).length > 0 && (
        <div>
          <h3 className="font-semibold mb-3">Additional Items</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead className="text-right">Taken</TableHead>
                  <TableHead className="text-right">Return</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(additionalItems).map(([item, data]: [string, any]) => (
                  <TableRow key={item}>
                    <TableCell className="font-medium">{item}</TableCell>
                    <TableCell className="text-right">{data.taken || 0}</TableCell>
                    <TableCell className="text-right">{data.return || 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Financial Summary */}
      <div>
        <h3 className="font-semibold mb-3">Financial Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Samosa Sales</p>
            <p className="font-medium font-mono">${report.totalSamosaSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Meal Sales</p>
            <p className="font-medium font-mono">${report.totalMealsSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Expenses</p>
            <p className="font-medium font-mono">${report.expenses || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Sales</p>
            <p className="font-medium font-mono">${report.totalSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Cash Sales</p>
            <p className="font-medium font-mono">${report.cashSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Mobile Sales</p>
            <p className="font-medium font-mono">${report.mobileSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Venmo</p>
            <p className="font-medium font-mono">${report.venmoSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Amount</p>
            <p className="font-medium font-mono">${report.totalAmount || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Tips (Online)</p>
            <p className="font-medium font-mono">${report.tipsOnline || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Tips (Offline)</p>
            <p className="font-medium font-mono">${report.tipsOffline || '0.00'}</p>
          </div>
          <div className="col-span-2 md:col-span-4">
            <p className="text-sm text-muted-foreground">Difference</p>
            <p className={`text-xl font-bold font-mono ${
              parseFloat(report.difference || '0') < 0 
                ? 'text-red-600 dark:text-red-500' 
                : 'text-green-600 dark:text-green-500'
            }`}>
              {parseFloat(report.difference || '0') < 0 
                ? `-$${Math.abs(parseFloat(report.difference || '0')).toFixed(2)}` 
                : `+$${parseFloat(report.difference || '0').toFixed(2)}`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
