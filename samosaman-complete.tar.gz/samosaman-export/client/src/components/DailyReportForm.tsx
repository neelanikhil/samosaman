import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SAMOSA_TYPES, SAMOSA_ORDER, type SamosaType, type Market, type DailyReport } from "@shared/schema";
import { Send, Save, MapPin, Plus } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";

interface SamosaData {
  taken: string;
  rnf: string;
  rf: string;
  gift: string;
  waste: string;
  eat: string;
}

interface AdditionalItemData {
  taken: string;
  returned: string;
}

interface DailyReportFormProps {
  draftReport?: DailyReport | null;
  onClearDraft?: () => void;
}

export function DailyReportForm({ draftReport, onClearDraft }: DailyReportFormProps) {
  const { toast } = useToast();
  const [marketName, setMarketName] = useState("");
  const [employeeName, setEmployeeName] = useState("");
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [day, setDay] = useState("");
  const [shiftStart, setShiftStart] = useState("10:00");
  const [shiftEnd, setShiftEnd] = useState("19:00");
  const [newMarketDialogOpen, setNewMarketDialogOpen] = useState(false);
  const [newMarketName, setNewMarketName] = useState("");
  const [isDraft, setIsDraft] = useState(false);

  const { data: markets } = useQuery<Market[]>({
    queryKey: ["/api/markets"],
  });

  const createMarketMutation = useMutation({
    mutationFn: async (name: string) => {
      const response = await fetch('/api/markets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
      });
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to create market');
      }
      return response.json() as Promise<Market>;
    },
    onSuccess: (newMarket) => {
      queryClient.invalidateQueries({ queryKey: ["/api/markets"] });
      setMarketName(newMarket.name);
      setNewMarketDialogOpen(false);
      setNewMarketName("");
      toast({
        title: "Market Added",
        description: `${newMarket.name} has been added successfully.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const [samosaData, setSamosaData] = useState<Record<SamosaType, SamosaData>>(
    SAMOSA_ORDER.reduce((acc, type) => ({
      ...acc,
      [type]: { taken: "", rnf: "", rf: "", gift: "", waste: "", eat: "" }
    }), {} as Record<SamosaType, SamosaData>)
  );

  const [additionalItems, setAdditionalItems] = useState<Record<string, AdditionalItemData>>({
    CCM: { taken: "", returned: "" },
    CPM: { taken: "", returned: "" },
    RICE: { taken: "", returned: "" },
    SSS: { taken: "", returned: "" },
  });

  const [fullMealsQty, setFullMealsQty] = useState("");
  const [fullMealPrice, setFullMealPrice] = useState("13");
  const [halfMealsQty, setHalfMealsQty] = useState("");
  const [halfMealPrice, setHalfMealPrice] = useState("7");

  const [expenses, setExpenses] = useState("");
  const [cashSales, setCashSales] = useState("");
  const [mobileSales, setMobileSales] = useState("");
  const [venmoSales, setVenmoSales] = useState("");
  const [tipsOnline, setTipsOnline] = useState("");
  const [tipsOffline, setTipsOffline] = useState("");
  const [note, setNote] = useState("");
  const [editingReportId, setEditingReportId] = useState<string | null>(null);

  // Load draft report data when provided, or reset when cleared
  useEffect(() => {
    if (draftReport) {
      setEditingReportId(draftReport.id);
      setMarketName(draftReport.marketName || "");
      setEmployeeName(draftReport.employeeName || "");
      setDate(draftReport.date || new Date().toISOString().split('T')[0]);
      setDay(draftReport.day || "");
      setShiftStart(draftReport.shiftStart || "10:00");
      setShiftEnd(draftReport.shiftEnd || "19:00");
      
      if (draftReport.samosaData) {
        setSamosaData(JSON.parse(draftReport.samosaData));
      }
      
      if (draftReport.additionalItems) {
        setAdditionalItems(JSON.parse(draftReport.additionalItems));
      } else {
        // Load from individual fields if additionalItems is not set
        setAdditionalItems({
          CCM: { 
            taken: draftReport.ccmTaken || "", 
            returned: draftReport.ccmReturn || "" 
          },
          CPM: { 
            taken: draftReport.cpmTaken || "", 
            returned: draftReport.cpmReturn || "" 
          },
          RICE: { 
            taken: draftReport.riceTaken || "", 
            returned: draftReport.riceReturn || "" 
          },
          SSS: { 
            taken: draftReport.sssTaken || "", 
            returned: draftReport.sssReturn || "" 
          },
        });
      }
      
      setFullMealsQty(draftReport.fullMealsQty || "");
      setFullMealPrice(draftReport.fullMealPrice || "13");
      setHalfMealsQty(draftReport.halfMealsQty || "");
      setHalfMealPrice(draftReport.halfMealPrice || "7");
      setExpenses(draftReport.expenses || "");
      setCashSales(draftReport.cashSales || "");
      setMobileSales(draftReport.mobileSales || "");
      setVenmoSales(draftReport.venmoSales || "");
      setTipsOnline(draftReport.tipsOnline || "");
      setTipsOffline(draftReport.tipsOffline || "");
      setNote(draftReport.note || "");
    } else if (draftReport === null && editingReportId) {
      // Reset form when draft is explicitly cleared
      setEditingReportId(null);
      setMarketName("");
      setEmployeeName("");
      setDate(new Date().toISOString().split('T')[0]);
      setDay("");
      setShiftStart("10:00");
      setShiftEnd("19:00");
      
      setSamosaData(
        SAMOSA_ORDER.reduce((acc, type) => ({
          ...acc,
          [type]: { taken: "", rnf: "", rf: "", gift: "", waste: "", eat: "" }
        }), {} as Record<SamosaType, SamosaData>)
      );
      
      setAdditionalItems({
        CCM: { taken: "", returned: "" },
        CPM: { taken: "", returned: "" },
        RICE: { taken: "", returned: "" },
        SSS: { taken: "", returned: "" },
      });
      
      setFullMealsQty("");
      setFullMealPrice("13");
      setHalfMealsQty("");
      setHalfMealPrice("7");
      setExpenses("");
      setCashSales("");
      setMobileSales("");
      setVenmoSales("");
      setTipsOnline("");
      setTipsOffline("");
      setNote("");
    }
  }, [draftReport, editingReportId]);

  const parseNum = (val: string) => parseFloat(val) || 0;

  const calculateSold = (type: SamosaType) => {
    const data = samosaData[type];
    return Math.max(0, 
      parseNum(data.taken) - parseNum(data.rnf) - parseNum(data.rf) - 
      parseNum(data.gift) - parseNum(data.waste) - parseNum(data.eat)
    );
  };

  const calculateSamosaSales = (type: SamosaType) => {
    return calculateSold(type) * 4;
  };

  const totalSamosaSales = SAMOSA_ORDER.reduce((sum, type) => 
    sum + calculateSamosaSales(type as SamosaType), 0
  );

  const fullMealsTotal = parseNum(fullMealsQty) * parseNum(fullMealPrice);
  const halfMealsTotal = parseNum(halfMealsQty) * parseNum(halfMealPrice);
  const totalMealsSales = fullMealsTotal + halfMealsTotal;

  const totalSales = totalSamosaSales + totalMealsSales - parseNum(expenses);
  const totalAmount = parseNum(cashSales) + parseNum(mobileSales) + parseNum(venmoSales);
  const difference = parseNum(expenses) + totalSamosaSales + totalMealsSales - parseNum(cashSales) - parseNum(mobileSales) - parseNum(venmoSales);

  const handleSaveDraft = async () => {
    if (!marketName || !employeeName) {
      toast({
        title: "Missing Information",
        description: "Please select market and enter employee name.",
        variant: "destructive",
      });
      return;
    }

    const reportData = {
      marketName,
      employeeName,
      date,
      day,
      shiftStart,
      shiftEnd,
      samosaData: JSON.stringify(samosaData),
      additionalItems: JSON.stringify(additionalItems),
      fullMealsQty: "",
      fullMealPrice: "",
      halfMealsQty: "",
      halfMealPrice: "",
      ccmTaken: additionalItems.CCM?.taken || "",
      ccmReturn: additionalItems.CCM?.returned || "",
      cpmTaken: additionalItems.CPM?.taken || "",
      cpmReturn: additionalItems.CPM?.returned || "",
      riceTaken: additionalItems.RICE?.taken || "",
      riceReturn: additionalItems.RICE?.returned || "",
      sssTaken: additionalItems.SSS?.taken || "",
      sssReturn: additionalItems.SSS?.returned || "",
      expenses: "",
      cashSales: "",
      mobileSales: "",
      venmoSales: "",
      tipsOnline: "",
      tipsOffline: "",
      totalSamosaSales: "0",
      totalMealsSales: "0",
      totalSales: "0",
      totalAmount: "0",
      difference: "0",
      status: "draft",
      note: note || "",
    };

    try {
      const url = editingReportId ? `/api/reports/${editingReportId}` : '/api/reports';
      const method = editingReportId ? 'PATCH' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reportData),
      });

      if (response.ok) {
        await queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
        
        // Clear draft state
        setEditingReportId(null);
        if (onClearDraft) onClearDraft();
        
        toast({
          title: editingReportId ? "Draft Updated!" : "Draft Saved!",
          description: editingReportId 
            ? "Report updated successfully. You can continue editing or submit it."
            : "Report saved as draft. You can update it later from My Reports.",
        });
        
        setTimeout(() => {
          const savedReportsTab = document.querySelector('[data-testid="tab-saved-reports"]') as HTMLElement;
          if (savedReportsTab) {
            savedReportsTab.click();
          }
        }, 500);
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to save draft.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error saving draft:', error);
      toast({
        title: "Error",
        description: "Failed to save draft. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleSubmit = async () => {
    if (!marketName || !employeeName) {
      toast({
        title: "Missing Information",
        description: "Please select market and enter employee name.",
        variant: "destructive",
      });
      return;
    }

    const reportData = {
      marketName,
      employeeName,
      date,
      day,
      shiftStart,
      shiftEnd,
      samosaData: JSON.stringify(samosaData),
      additionalItems: JSON.stringify(additionalItems),
      fullMealsQty,
      fullMealPrice,
      halfMealsQty,
      halfMealPrice,
      ccmTaken: additionalItems.CCM?.taken || "",
      ccmReturn: additionalItems.CCM?.returned || "",
      cpmTaken: additionalItems.CPM?.taken || "",
      cpmReturn: additionalItems.CPM?.returned || "",
      riceTaken: additionalItems.RICE?.taken || "",
      riceReturn: additionalItems.RICE?.returned || "",
      sssTaken: additionalItems.SSS?.taken || "",
      sssReturn: additionalItems.SSS?.returned || "",
      expenses,
      cashSales,
      mobileSales,
      venmoSales,
      tipsOnline,
      tipsOffline,
      totalSamosaSales: totalSamosaSales.toString(),
      totalMealsSales: totalMealsSales.toString(),
      totalSales: totalSales.toString(),
      totalAmount: totalAmount.toString(),
      difference: difference.toString(),
      status: "submitted",
      note: note || "",
    };

    try {
      const url = editingReportId ? `/api/reports/${editingReportId}` : '/api/reports';
      const method = editingReportId ? 'PATCH' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reportData),
      });

      if (response.ok) {
        await queryClient.invalidateQueries({ queryKey: ['/api/reports'] });
        
        // Clear draft state
        setEditingReportId(null);
        if (onClearDraft) onClearDraft();
        
        toast({
          title: "Success!",
          description: "Report submitted successfully. Inventory has been updated. Switching to My Reports...",
        });
        
        setTimeout(() => {
          const savedReportsTab = document.querySelector('[data-testid="tab-saved-reports"]') as HTMLElement;
          if (savedReportsTab) {
            savedReportsTab.click();
          }
        }, 500);
      } else {
        const error = await response.json();
        toast({
          title: "Error",
          description: error.error || "Failed to submit report.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error submitting report:', error);
      toast({
        title: "Error",
        description: "Failed to submit report. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Daily Market Report</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="market">Market</Label>
              <div className="flex gap-2">
                <Select value={marketName} onValueChange={(value) => {
                  if (value === "__add_new__") {
                    setNewMarketDialogOpen(true);
                  } else {
                    setMarketName(value);
                  }
                }}>
                  <SelectTrigger id="market" data-testid="select-market" className="flex-1">
                    <SelectValue placeholder="Select market" />
                  </SelectTrigger>
                  <SelectContent>
                    {markets?.map((market) => (
                      <SelectItem key={market.id} value={market.name}>
                        {market.name}
                      </SelectItem>
                    ))}
                    <SelectItem value="__add_new__" className="text-primary font-medium">
                      <div className="flex items-center gap-2">
                        <Plus className="h-4 w-4" />
                        Add New Market
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                
                <Dialog open={newMarketDialogOpen} onOpenChange={setNewMarketDialogOpen}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Market</DialogTitle>
                      <DialogDescription>
                        Enter the name of the new market location.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="new-market-name">Market Name</Label>
                        <Input
                          id="new-market-name"
                          placeholder="e.g. Central Square FM"
                          value={newMarketName}
                          onChange={(e) => setNewMarketName(e.target.value)}
                          data-testid="input-new-market"
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button
                        onClick={() => {
                          if (newMarketName.trim()) {
                            createMarketMutation.mutate(newMarketName.trim());
                          }
                        }}
                        disabled={!newMarketName.trim() || createMarketMutation.isPending}
                        data-testid="button-create-market"
                      >
                        {createMarketMutation.isPending ? "Adding..." : "Add Market"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input
                id="date"
                type="date"
                data-testid="input-date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="day">Day</Label>
              <Select value={day} onValueChange={setDay}>
                <SelectTrigger id="day" data-testid="select-day">
                  <SelectValue placeholder="Select day" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Monday">Monday</SelectItem>
                  <SelectItem value="Tuesday">Tuesday</SelectItem>
                  <SelectItem value="Wednesday">Wednesday</SelectItem>
                  <SelectItem value="Thursday">Thursday</SelectItem>
                  <SelectItem value="Friday">Friday</SelectItem>
                  <SelectItem value="Saturday">Saturday</SelectItem>
                  <SelectItem value="Sunday">Sunday</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="shiftStart">Shift Start</Label>
              <Input
                id="shiftStart"
                type="time"
                data-testid="input-shift-start"
                value={shiftStart}
                onChange={(e) => setShiftStart(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="shiftEnd">Shift End</Label>
              <Input
                id="shiftEnd"
                type="time"
                data-testid="input-shift-end"
                value={shiftEnd}
                onChange={(e) => setShiftEnd(e.target.value)}
              />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="employeeName">Employee Name</Label>
              <Input
                id="employeeName"
                data-testid="input-employee-name"
                placeholder="Akhi & Shiva"
                value={employeeName}
                onChange={(e) => setEmployeeName(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Samosa Sales</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[150px]">Type</TableHead>
                  <TableHead className="text-center">Taken</TableHead>
                  <TableHead className="text-center">RNF</TableHead>
                  <TableHead className="text-center">RF</TableHead>
                  <TableHead className="text-center">Gift</TableHead>
                  <TableHead className="text-center">Waste</TableHead>
                  <TableHead className="text-center">Eat</TableHead>
                  <TableHead className="text-center">Sold</TableHead>
                  <TableHead className="text-center">Sales</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {SAMOSA_ORDER.map((code) => {
                  const name = SAMOSA_TYPES[code];
                  return (
                  <TableRow key={code} data-testid={`row-samosa-${code.toLowerCase()}`}>
                    <TableCell className="font-medium">{code} - {name}</TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-taken-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].taken}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], taken: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-rnf-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].rnf}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], rnf: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-rf-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].rf}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], rf: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-gift-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].gift}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], gift: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-waste-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].waste}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], waste: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell>
                      <Input
                        type="number"
                        min="0"
                        className="w-20 text-center font-mono"
                        data-testid={`input-eat-${code.toLowerCase()}`}
                        value={samosaData[code as SamosaType].eat}
                        onChange={(e) => setSamosaData({
                          ...samosaData,
                          [code]: { ...samosaData[code as SamosaType], eat: e.target.value }
                        })}
                        placeholder=""
                      />
                    </TableCell>
                    <TableCell className="text-center font-mono font-semibold" data-testid={`text-sold-${code.toLowerCase()}`}>
                      {calculateSold(code as SamosaType)}
                    </TableCell>
                    <TableCell className="text-center font-mono font-semibold text-chart-3" data-testid={`text-sales-${code.toLowerCase()}`}>
                      ${calculateSamosaSales(code as SamosaType).toFixed(2)}
                    </TableCell>
                  </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
          <div className="mt-4 flex justify-end border-t pt-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Samosa Sales</p>
              <p className="text-2xl font-bold text-chart-3 font-mono" data-testid="text-total-samosa-sales">
                ${totalSamosaSales.toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Additional Items</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead className="text-center">Taken</TableHead>
                  <TableHead className="text-center">Return</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(additionalItems).map(([item, data]) => (
                  <TableRow key={item} data-testid={`row-additional-${item.toLowerCase()}`}>
                    <TableCell className="font-medium capitalize">{item}</TableCell>
                    <TableCell>
                      <Select
                        value={data.taken}
                        onValueChange={(value) => setAdditionalItems({
                          ...additionalItems,
                          [item]: { ...data, taken: value }
                        })}
                      >
                        <SelectTrigger className="w-24" data-testid={`select-taken-${item.toLowerCase()}`}>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0.25">1/4</SelectItem>
                          <SelectItem value="0.5">1/2</SelectItem>
                          <SelectItem value="0.75">3/4</SelectItem>
                          <SelectItem value="1">1</SelectItem>
                          <SelectItem value="2">2</SelectItem>
                          <SelectItem value="3">3</SelectItem>
                          <SelectItem value="4">4</SelectItem>
                          <SelectItem value="5">5</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Select
                        value={data.returned}
                        onValueChange={(value) => setAdditionalItems({
                          ...additionalItems,
                          [item]: { ...data, returned: value }
                        })}
                      >
                        <SelectTrigger className="w-24" data-testid={`select-return-${item.toLowerCase()}`}>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="0.25">1/4</SelectItem>
                          <SelectItem value="0.5">1/2</SelectItem>
                          <SelectItem value="0.75">3/4</SelectItem>
                          <SelectItem value="1">1</SelectItem>
                          <SelectItem value="2">2</SelectItem>
                          <SelectItem value="3">3</SelectItem>
                          <SelectItem value="4">4</SelectItem>
                          <SelectItem value="5">5</SelectItem>
                        </SelectContent>
                      </Select>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Full & Half Meals</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Full Meals</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="full-meals-qty">Quantity</Label>
                  <Input
                    id="full-meals-qty"
                    type="number"
                    min="0"
                    className="font-mono"
                    data-testid="input-full-meals-qty"
                    value={fullMealsQty}
                    onChange={(e) => setFullMealsQty(e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="full-meal-price">Price ($)</Label>
                  <Input
                    id="full-meal-price"
                    type="number"
                    min="0"
                    step="0.01"
                    className="font-mono"
                    data-testid="input-full-meal-price"
                    value={fullMealPrice}
                    onChange={(e) => setFullMealPrice(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="text-right pt-2 border-t">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-lg font-semibold text-chart-3 font-mono" data-testid="text-full-meals-total">
                  ${fullMealsTotal.toFixed(2)}
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-medium">Half Meals</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="half-meals-qty">Quantity</Label>
                  <Input
                    id="half-meals-qty"
                    type="number"
                    min="0"
                    className="font-mono"
                    data-testid="input-half-meals-qty"
                    value={halfMealsQty}
                    onChange={(e) => setHalfMealsQty(e.target.value)}
                    placeholder="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="half-meal-price">Price ($)</Label>
                  <Input
                    id="half-meal-price"
                    type="number"
                    min="0"
                    step="0.01"
                    className="font-mono"
                    data-testid="input-half-meal-price"
                    value={halfMealPrice}
                    onChange={(e) => setHalfMealPrice(e.target.value)}
                    placeholder="0.00"
                  />
                </div>
              </div>
              <div className="text-right pt-2 border-t">
                <p className="text-sm text-muted-foreground">Total</p>
                <p className="text-lg font-semibold text-chart-3 font-mono" data-testid="text-half-meals-total">
                  ${halfMealsTotal.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-end border-t pt-4">
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Meals Sales</p>
              <p className="text-2xl font-bold text-chart-3 font-mono" data-testid="text-total-meals-sales">
                ${totalMealsSales.toFixed(2)}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Sales & Expenses</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label htmlFor="expenses">Expenses ($)</Label>
            <Input
              id="expenses"
              type="number"
              min="0"
              step="0.01"
              className="mt-2 font-mono"
              data-testid="input-expenses"
              value={expenses}
              onChange={(e) => setExpenses(e.target.value)}
              placeholder="0.00"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="cash-sales">Cash Sales ($)</Label>
              <Input
                id="cash-sales"
                type="number"
                min="0"
                step="0.01"
                className="mt-2 font-mono"
                data-testid="input-cash-sales"
                value={cashSales}
                onChange={(e) => setCashSales(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="mobile-sales">Mobile Sales ($)</Label>
              <Input
                id="mobile-sales"
                type="number"
                min="0"
                step="0.01"
                className="mt-2 font-mono"
                data-testid="input-mobile-sales"
                value={mobileSales}
                onChange={(e) => setMobileSales(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="venmo-sales">Venmo Sales ($)</Label>
              <Input
                id="venmo-sales"
                type="number"
                min="0"
                step="0.01"
                className="mt-2 font-mono"
                data-testid="input-venmo-sales"
                value={venmoSales}
                onChange={(e) => setVenmoSales(e.target.value)}
                placeholder="0.00"
              />
            </div>
            <div>
              <Label htmlFor="tips-online">Tips Online ($)</Label>
              <Input
                id="tips-online"
                type="number"
                min="0"
                step="0.01"
                className="mt-2 font-mono"
                data-testid="input-tips-online"
                value={tipsOnline}
                onChange={(e) => setTipsOnline(e.target.value)}
                placeholder="0.00"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="tips-offline">Tips Offline ($)</Label>
            <Input
              id="tips-offline"
              type="number"
              min="0"
              step="0.01"
              className="mt-2 font-mono"
              data-testid="input-tips-offline"
              value={tipsOffline}
              onChange={(e) => setTipsOffline(e.target.value)}
              placeholder="0.00"
            />
          </div>
        </CardContent>
      </Card>

      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle>Summary</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-muted-foreground">Total Samosa Sales</p>
              <p className="text-lg font-semibold text-chart-3 font-mono" data-testid="text-summary-samosa-sales">
                ${totalSamosaSales.toFixed(2)}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">Total Meals Sales</p>
              <p className="text-lg font-semibold text-chart-3 font-mono" data-testid="text-summary-meals-sales">
                ${totalMealsSales.toFixed(2)}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">Total Sales</p>
              <p className="text-lg font-semibold text-chart-3 font-mono" data-testid="text-summary-total-sales">
                ${totalSales.toFixed(2)}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">Expenses</p>
              <p className="text-lg font-semibold text-destructive font-mono" data-testid="text-summary-expenses">
                ${parseNum(expenses).toFixed(2)}
              </p>
            </div>
          </div>
          <div className="border-t pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-muted-foreground">Total Amount</p>
                <p className="text-2xl font-bold text-chart-2 font-mono" data-testid="text-summary-total-amount">
                  ${totalAmount.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-muted-foreground">Difference</p>
                <p className={`text-2xl font-bold font-mono ${difference >= 0 ? 'text-chart-3' : 'text-destructive'}`} data-testid="text-summary-difference">
                  ${difference.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Note Section */}
      <Card>
        <CardHeader>
          <CardTitle>Note</CardTitle>
        </CardHeader>
        <CardContent>
          <Label htmlFor="note">Employee Notes (Optional)</Label>
          <Textarea
            id="note"
            className="mt-2"
            data-testid="textarea-note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Write any notes or observations about today's market…"
            rows={4}
          />
        </CardContent>
      </Card>

      <div className="flex gap-4 justify-end">
        <Button
          size="lg"
          variant="outline"
          onClick={handleSaveDraft}
          disabled={!marketName || !employeeName}
          data-testid="button-save-draft"
        >
          <Save className="mr-2 h-5 w-5" />
          Save Draft
        </Button>
        <Button
          size="lg"
          onClick={handleSubmit}
          disabled={!marketName || !employeeName}
          data-testid="button-submit-report"
        >
          <Send className="mr-2 h-5 w-5" />
          Submit Report
        </Button>
      </div>
    </div>
  );
}
