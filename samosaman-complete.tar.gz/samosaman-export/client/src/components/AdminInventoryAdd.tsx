import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { SAMOSA_TYPES, SAMOSA_ORDER, type SamosaType, type Inventory } from "@shared/schema";
import { Plus, Package, CheckCircle2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function AdminInventoryAdd() {
  const { toast } = useToast();
  const [inventory, setInventory] = useState<Record<SamosaType, number>>(
    Object.keys(SAMOSA_TYPES).reduce((acc, type) => ({
      ...acc,
      [type]: 0
    }), {} as Record<SamosaType, number>)
  );

  const { data: currentInventory } = useQuery<Inventory[]>({
    queryKey: ["/api/inventory"],
  });

  const addInventoryMutation = useMutation({
    mutationFn: async (data: Record<string, number>) => {
      const response = await fetch('/api/inventory/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ inventory: data }),
      });
      if (!response.ok) {
        throw new Error('Failed to add inventory');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      setInventory(
        Object.keys(SAMOSA_TYPES).reduce((acc, type) => ({
          ...acc,
          [type]: 0
        }), {} as Record<SamosaType, number>)
      );
      toast({
        title: "Inventory Added",
        description: "Inventory quantities have been successfully added.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const totalToAdd = Object.values(inventory).reduce((sum, qty) => sum + qty, 0);

  const handleAddInventory = () => {
    if (totalToAdd === 0) {
      toast({
        title: "No Items to Add",
        description: "Please enter quantities to add to inventory.",
        variant: "destructive",
      });
      return;
    }
    addInventoryMutation.mutate(inventory);
  };

  const getInventoryItem = (samosaType: string) => {
    return currentInventory?.find(item => item.samosaType === samosaType);
  };

  const calculateRemaining = (item?: Inventory) => {
    if (!item) return 0;
    return item.initialQuantity - item.sold - item.gift - item.waste - item.eat;
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Add Inventory
          </CardTitle>
          <CardDescription>Add quantities to existing inventory for all samosa types (includes CCM & CPM)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {SAMOSA_ORDER.map((code) => {
              const name = SAMOSA_TYPES[code];
              const item = getInventoryItem(code);
              const remaining = calculateRemaining(item);
              return (
                <div key={code} className="space-y-2" data-testid={`card-add-inventory-${code.toLowerCase()}`}>
                  <div className="flex items-center justify-between gap-2">
                    <Badge variant="secondary">{code}</Badge>
                    {item && (
                      <span className="text-xs text-muted-foreground font-mono">
                        Rem: {remaining}
                      </span>
                    )}
                  </div>
                  <Label className="text-xs text-muted-foreground">{name}</Label>
                  <Input
                    type="number"
                    min="0"
                    data-testid={`input-add-inventory-${code.toLowerCase()}`}
                    value={inventory[code as SamosaType]}
                    onChange={(e) => setInventory({
                      ...inventory,
                      [code]: Number(e.target.value)
                    })}
                    className="font-mono text-lg"
                    placeholder="0"
                  />
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Package className="h-8 w-8 text-primary" />
              <div>
                <div className="text-sm text-muted-foreground">Total to Add</div>
                <div className="text-3xl font-bold font-mono" data-testid="text-total-to-add">
                  {totalToAdd}
                </div>
              </div>
            </div>
            <Button 
              onClick={handleAddInventory} 
              data-testid="button-add-inventory" 
              size="lg" 
              className="gap-2"
              disabled={addInventoryMutation.isPending}
            >
              {addInventoryMutation.isPending ? (
                <>Processing...</>
              ) : (
                <>
                  <Plus className="h-5 w-5" />
                  Add to Inventory
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {currentInventory && currentInventory.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Current Inventory Status</CardTitle>
            <CardDescription>Initial quantities and current inventory levels</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {SAMOSA_ORDER.map((code) => {
                const item = currentInventory?.find(inv => inv.samosaType === code);
                if (!item) return null;
                  const current = calculateRemaining(item);
                  return (
                    <Card key={item.id} className="p-4" data-testid={`card-inventory-status-${item.samosaType.toLowerCase()}`}>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Badge variant="secondary" className="text-sm">{item.samosaType}</Badge>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {SAMOSA_TYPES[item.samosaType as keyof typeof SAMOSA_TYPES]}
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-muted-foreground">Initial:</span>
                            <span className="font-mono font-semibold text-muted-foreground" data-testid={`text-initial-${item.samosaType.toLowerCase()}`}>
                              {item.initialQuantity}
                            </span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Current:</span>
                            <span 
                              className={`font-mono font-bold text-lg ${current <= 0 ? 'text-red-600 dark:text-red-500' : 'text-green-600 dark:text-green-500'}`}
                              data-testid={`text-current-${item.samosaType.toLowerCase()}`}
                            >
                              {current}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
