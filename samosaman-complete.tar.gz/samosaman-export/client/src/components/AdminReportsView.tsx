import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, MapPin, User, Eye, Download, DollarSign } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import type { DailyReport } from "@shared/schema";

export function AdminReportsView() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedReport, setSelectedReport] = useState<DailyReport | null>(null);

  const { data: allReports, isLoading } = useQuery<DailyReport[]>({
    queryKey: ['/api/reports'],
  });

  const filteredReports = allReports?.filter(report => report.date === selectedDate) || [];

  const downloadReport = (report: DailyReport) => {
    const samosaData = report.samosaData ? JSON.parse(report.samosaData) : {};
    
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Samosa Man - Daily Report\n\n";
    csvContent += `Market,${report.marketName}\n`;
    csvContent += `Employee,${report.employeeName}\n`;
    csvContent += `Date,${report.date}\n`;
    csvContent += `Day,${report.day || '-'}\n`;
    csvContent += `Shift,${report.shiftStart || '-'} to ${report.shiftEnd || '-'}\n\n`;
    
    csvContent += "Samosa Sales\n";
    csvContent += "Type,Taken,RNF,RF,Gift,Waste,Eat,Sold,Sales\n";
    Object.entries(samosaData).forEach(([type, data]: [string, any]) => {
      const parseNum = (val: string | number) => parseFloat(String(val)) || 0;
      const sold = Math.max(0, 
        parseNum(data.taken) - parseNum(data.rnf) - parseNum(data.rf) - 
        parseNum(data.gift) - parseNum(data.waste) - parseNum(data.eat)
      );
      const sales = sold * 4;
      csvContent += `${type},${data.taken || 0},${data.rnf || 0},${data.rf || 0},${data.gift || 0},${data.waste || 0},${data.eat || 0},${sold},${sales}\n`;
    });
    
    csvContent += "\nFinancial Summary\n";
    csvContent += `Samosa Sales,${report.totalSamosaSales || 0}\n`;
    csvContent += `Meal Sales,${report.totalMealsSales || 0}\n`;
    csvContent += `Expenses,${report.expenses || 0}\n`;
    csvContent += `Total Sales,${report.totalSales || 0}\n`;
    csvContent += `Cash Sales,${report.cashSales || 0}\n`;
    csvContent += `Mobile Sales,${report.mobileSales || 0}\n`;
    csvContent += `Venmo,${report.venmoSales || 0}\n`;
    csvContent += `Total Amount,${report.totalAmount || 0}\n`;
    csvContent += `Difference,${report.difference || 0}\n`;
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `report_${report.marketName}_${report.date}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground">Loading reports...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Filter Reports</CardTitle>
            <CardDescription>Select a date to view reports</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="max-w-xs">
              <Label htmlFor="reportDate">
                <Calendar className="h-4 w-4 inline mr-1" />
                Select Date
              </Label>
              <Input
                id="reportDate"
                type="date"
                data-testid="input-report-date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Reports for {selectedDate}
            </CardTitle>
            <CardDescription>
              {filteredReports.length} {filteredReports.length === 1 ? 'report' : 'reports'} found
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredReports.length > 0 ? (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Day</TableHead>
                    <TableHead>Market</TableHead>
                    <TableHead>Employee</TableHead>
                    <TableHead className="text-right">Total Amount</TableHead>
                    <TableHead className="text-right">Difference</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-center">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReports.map((report) => (
                    <TableRow key={report.id} data-testid={`row-report-${report.id}`}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="font-mono text-sm">{report.date}</span>
                        </div>
                      </TableCell>
                      <TableCell>{report.day || '-'}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span>{report.marketName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span>{report.employeeName}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        <div className="flex items-center justify-end gap-1">
                          <DollarSign className="h-4 w-4 text-muted-foreground" />
                          {report.totalAmount || '0.00'}
                        </div>
                      </TableCell>
                      <TableCell className="text-right font-mono">
                        <span className={
                          parseFloat(report.difference || '0') < 0 
                            ? 'text-red-600 dark:text-red-500 font-semibold' 
                            : 'text-green-600 dark:text-green-500 font-semibold'
                        }>
                          ${report.difference || '0.00'}
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="inline-flex items-center rounded-md bg-green-50 dark:bg-green-900/20 px-2 py-1 text-xs font-medium text-green-700 dark:text-green-400 ring-1 ring-inset ring-green-600/20 dark:ring-green-500/20">
                          {report.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex gap-1 justify-center">
                          <Button
                            variant="ghost"
                            size="sm"
                            data-testid={`button-view-${report.id}`}
                            onClick={() => setSelectedReport(report)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            data-testid={`button-download-${report.id}`}
                            onClick={() => downloadReport(report)}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No reports found for this date
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={!!selectedReport} onOpenChange={() => setSelectedReport(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Report Details</DialogTitle>
          </DialogHeader>
          {selectedReport && <ReportDetailsView report={selectedReport} />}
        </DialogContent>
      </Dialog>
    </>
  );
}

function ReportDetailsView({ report }: { report: DailyReport }) {
  const samosaData = report.samosaData ? JSON.parse(report.samosaData) : {};
  const additionalItems = report.additionalItems ? JSON.parse(report.additionalItems) : {};

  const parseNum = (val: string | number) => parseFloat(String(val)) || 0;

  const calculateSold = (data: any) => {
    return Math.max(0, 
      parseNum(data.taken) - parseNum(data.rnf) - parseNum(data.rf) - 
      parseNum(data.gift) - parseNum(data.waste) - parseNum(data.eat)
    );
  };

  const calculateSales = (data: any) => {
    return calculateSold(data) * 4;
  };

  return (
    <div className="space-y-6">
      {/* Basic Information */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div>
          <p className="text-sm text-muted-foreground">Market</p>
          <p className="font-medium" data-testid="text-market">{report.marketName}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Date</p>
          <p className="font-medium" data-testid="text-date">{report.date}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Day</p>
          <p className="font-medium" data-testid="text-day">{report.day || '-'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Employee</p>
          <p className="font-medium" data-testid="text-employee">{report.employeeName}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Shift Start</p>
          <p className="font-medium" data-testid="text-shift-start">{report.shiftStart || '-'}</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground">Shift End</p>
          <p className="font-medium" data-testid="text-shift-end">{report.shiftEnd || '-'}</p>
        </div>
      </div>

      {/* Samosa Sales Data */}
      {Object.keys(samosaData).length > 0 && (
        <div>
          <h3 className="font-semibold mb-3">Samosa Sales</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-right">Taken</TableHead>
                  <TableHead className="text-right">RNF</TableHead>
                  <TableHead className="text-right">RF</TableHead>
                  <TableHead className="text-right">Gift</TableHead>
                  <TableHead className="text-right">Waste</TableHead>
                  <TableHead className="text-right">Eat</TableHead>
                  <TableHead className="text-right">Sold</TableHead>
                  <TableHead className="text-right">Sales</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(samosaData).map(([type, data]: [string, any]) => {
                  const sold = calculateSold(data);
                  const sales = calculateSales(data);
                  return (
                    <TableRow key={type}>
                      <TableCell className="font-medium">{type}</TableCell>
                      <TableCell className="text-right">{data.taken || 0}</TableCell>
                      <TableCell className="text-right">{data.rnf || 0}</TableCell>
                      <TableCell className="text-right">{data.rf || 0}</TableCell>
                      <TableCell className="text-right">{data.gift || 0}</TableCell>
                      <TableCell className="text-right">{data.waste || 0}</TableCell>
                      <TableCell className="text-right">{data.eat || 0}</TableCell>
                      <TableCell className="text-right font-semibold">{sold}</TableCell>
                      <TableCell className="text-right font-mono">${sales.toFixed(2)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Meals Section */}
      <div>
        <h3 className="font-semibold mb-3">Meals</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Full Meals Qty</p>
            <p className="font-medium">{report.fullMealsQty || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Full Meal Price</p>
            <p className="font-medium font-mono">${report.fullMealPrice || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Half Meals Qty</p>
            <p className="font-medium">{report.halfMealsQty || 0}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Half Meal Price</p>
            <p className="font-medium font-mono">${report.halfMealPrice || '0.00'}</p>
          </div>
        </div>
      </div>

      {/* Additional Items */}
      {Object.keys(additionalItems).length > 0 && (
        <div>
          <h3 className="font-semibold mb-3">Additional Items</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item</TableHead>
                  <TableHead className="text-right">Taken</TableHead>
                  <TableHead className="text-right">Return</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {Object.entries(additionalItems).map(([item, data]: [string, any]) => (
                  <TableRow key={item}>
                    <TableCell className="font-medium">{item}</TableCell>
                    <TableCell className="text-right">{data.taken || 0}</TableCell>
                    <TableCell className="text-right">{data.return || 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Financial Summary */}
      <div>
        <h3 className="font-semibold mb-3">Financial Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Samosa Sales</p>
            <p className="font-medium font-mono">${report.totalSamosaSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Meal Sales</p>
            <p className="font-medium font-mono">${report.totalMealsSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Expenses</p>
            <p className="font-medium font-mono">${report.expenses || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Sales</p>
            <p className="font-medium font-mono">${report.totalSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Cash Sales</p>
            <p className="font-medium font-mono">${report.cashSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Mobile Sales</p>
            <p className="font-medium font-mono">${report.mobileSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Venmo</p>
            <p className="font-medium font-mono">${report.venmoSales || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Total Amount</p>
            <p className="font-medium font-mono">${report.totalAmount || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Tips (Online)</p>
            <p className="font-medium font-mono">${report.tipsOnline || '0.00'}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Tips (Offline)</p>
            <p className="font-medium font-mono">${report.tipsOffline || '0.00'}</p>
          </div>
          <div className="col-span-2 md:col-span-4">
            <p className="text-sm text-muted-foreground">Difference</p>
            <p className={`text-xl font-bold font-mono ${
              parseFloat(report.difference || '0') < 0 
                ? 'text-red-600 dark:text-red-500' 
                : 'text-green-600 dark:text-green-500'
            }`}>
              {parseFloat(report.difference || '0') < 0 
                ? `-$${Math.abs(parseFloat(report.difference || '0')).toFixed(2)}` 
                : `+$${parseFloat(report.difference || '0').toFixed(2)}`}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
