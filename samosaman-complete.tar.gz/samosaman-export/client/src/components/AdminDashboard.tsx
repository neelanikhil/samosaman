import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { DollarSign, ShoppingBag, TrendingUp, CalendarIcon } from "lucide-react";
import { SAMOSA_TYPES } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";

interface DashboardData {
  totalRevenue: number;
  totalSold: number;
  topMarket: { name: string; samosas: number } | null;
  samosaTypeSales: Array<{ name: string; value: number }>;
  marketSales: Array<{ name: string; revenue: number; samosas: number; date: string; day: string }>;
}

interface DateRange {
  from: Date | undefined;
  to: Date | undefined;
}

const CHART_COLORS = [
  "#DC3545", // Red - APP
  "#28A745", // Green - VEG
  "#007BFF", // Blue - PJB
  "#FD7E14", // Orange - VSP
  "#FFC107", // Yellow - SCH
  "#8B4513", // Brown - CHC
  "#6C757D", // Light Black (Dark Gray) - STC
  "#9B59B6", // Purple - STP
];

export function AdminDashboard() {
  // Initialize with last 30 days
  const [dateRange, setDateRange] = useState<DateRange>({
    from: new Date(new Date().setDate(new Date().getDate() - 30)),
    to: new Date(),
  });

  const { data: dashboardData, isLoading } = useQuery<DashboardData>({
    queryKey: ["/api/dashboard-data", dateRange.from?.toISOString(), dateRange.to?.toISOString()],
    queryFn: async () => {
      if (!dateRange.from || !dateRange.to) return null;
      const response = await fetch(
        `/api/dashboard-data?startDate=${dateRange.from.toISOString()}&endDate=${dateRange.to.toISOString()}`
      );
      if (!response.ok) throw new Error('Failed to fetch dashboard data');
      return response.json();
    },
    enabled: !!dateRange.from && !!dateRange.to,
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-[300px] justify-start text-left font-normal" data-testid="button-date-picker">
              <CalendarIcon className="mr-2 h-4 w-4" />
              {dateRange.from && dateRange.to ? (
                <>
                  {format(dateRange.from, "MMM d, yyyy")} - {format(dateRange.to, "MMM d, yyyy")}
                </>
              ) : (
                <span>Pick a date range</span>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="end">
            <Calendar
              mode="range"
              selected={{ from: dateRange.from, to: dateRange.to }}
              onSelect={(range: any) => setDateRange({ from: range?.from, to: range?.to })}
              numberOfMonths={2}
              data-testid="calendar-date-range"
            />
          </PopoverContent>
        </Popover>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-muted-foreground" />
              {isLoading ? (
                <Skeleton className="h-8 w-32" />
              ) : (
                <div className="text-2xl font-bold font-mono" data-testid="text-total-revenue">
                  ${(dashboardData?.totalRevenue || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Cash + Mobile + Venmo - Expenses
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Total Samosas Sold
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5 text-muted-foreground" />
              {isLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : (
                <div className="text-2xl font-bold font-mono" data-testid="text-total-sold">
                  {(dashboardData?.totalSold || 0).toLocaleString()}
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Selected date range
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Top Market
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
              {isLoading ? (
                <Skeleton className="h-8 w-24" />
              ) : dashboardData?.topMarket ? (
                <div className="flex flex-col">
                  <div className="text-2xl font-bold" data-testid="text-top-market">
                    {dashboardData.topMarket.name}
                  </div>
                  <div className="text-sm font-mono text-muted-foreground" data-testid="text-top-market-samosas">
                    {dashboardData.topMarket.samosas.toLocaleString()} samosas
                  </div>
                </div>
              ) : (
                <div className="text-sm text-muted-foreground">No data</div>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Most samosas sold
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Sales by Samosa Type</CardTitle>
            <CardDescription>Distribution of samosa sales in selected period</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : dashboardData?.samosaTypeSales && dashboardData.samosaTypeSales.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={dashboardData.samosaTypeSales.map((item, index) => ({
                      ...item,
                      color: CHART_COLORS[index % CHART_COLORS.length],
                    }))}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {dashboardData.samosaTypeSales.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "6px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No sales data available
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Sales by Market</CardTitle>
            <CardDescription>Total revenue with date and day information</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[300px] w-full" />
            ) : dashboardData?.marketSales && dashboardData.marketSales.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dashboardData.marketSales}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "6px",
                    }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-popover border border-border rounded-md p-3">
                            <p className="font-semibold">{data.name}</p>
                            <p className="text-sm">Revenue: ${data.revenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            <p className="text-sm">Samosas: {data.samosas}</p>
                            {data.date && <p className="text-sm text-muted-foreground">Date: {data.date}</p>}
                            {data.day && <p className="text-sm text-muted-foreground">Day: {data.day}</p>}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Legend />
                  <Bar dataKey="revenue" fill="hsl(var(--chart-1))" name="Total Revenue ($)" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[300px] flex items-center justify-center text-muted-foreground">
                No market data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
