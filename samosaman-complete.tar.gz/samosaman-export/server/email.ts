import sgMail from "@sendgrid/mail";

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL || process.env.ADMIN_EMAIL || "neelanikhil997@gmail.com";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "neelanikhil997@gmail.com";
const APP_URL = process.env.APP_URL || "https://samosaman.replit.app";

// SendGrid Dynamic Template IDs
const SG_TEMPLATE_WELCOME = process.env.SG_TEMPLATE_WELCOME;
const SG_TEMPLATE_APPROVAL = process.env.SG_TEMPLATE_APPROVAL;
const SG_TEMPLATE_LOW_INV = process.env.SG_TEMPLATE_LOW_INV;
const SG_TEMPLATE_REPORT_SUBMITTED = process.env.SG_TEMPLATE_REPORT_SUBMITTED;
const SG_TEMPLATE_DRAFT_SAVED = process.env.SG_TEMPLATE_DRAFT_SAVED;

if (SENDGRID_API_KEY) {
  sgMail.setApiKey(SENDGRID_API_KEY);
}

export async function sendWelcomeEmail(employeeEmail: string, employeeName: string, username: string) {
  if (!SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured. Skipping email send.");
    return false;
  }

  try {
    const msg: any = {
      to: employeeEmail,
      from: FROM_EMAIL,
      subject: "Welcome to SamosaMan - Pending Approval",
    };

    // Use dynamic template if configured, otherwise fall back to plain text/HTML
    if (SG_TEMPLATE_WELCOME) {
      msg.templateId = SG_TEMPLATE_WELCOME;
      msg.dynamicTemplateData = {
        employeeName,
        username,
        appUrl: APP_URL,
      };
    } else {
      msg.text = `Hello ${employeeName},\n\nThank you for registering with SamosaMan. Your account is pending admin approval. You will receive an email notification once your account is approved.\n\nYour username: ${username}\n\nBest regards,\nSamosaMan Admin Team`;
      msg.html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #27657D;">Welcome to SamosaMan!</h2>
          <p>Hello ${employeeName},</p>
          <p>Thank you for registering with <strong>SamosaMan</strong>.</p>
          <p>Your username: <strong>${username}</strong></p>
          <p>Your account is currently pending admin approval. You will receive an email notification once your account is approved and you can start using the system.</p>
          <br>
          <p>Best regards,<br>SamosaMan Admin Team</p>
        </div>
      `;
    }

    await sgMail.send(msg);
    console.log(`Welcome email sent to ${employeeEmail} using ${SG_TEMPLATE_WELCOME ? 'template' : 'HTML'}`);
    return true;
  } catch (error: any) {
    console.error("Error sending welcome email:", error.response?.body || error.message);
    return false;
  }
}

export async function sendApprovalEmail(employeeEmail: string, employeeName: string) {
  if (!SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured. Skipping email send.");
    return false;
  }

  try {
    const msg: any = {
      to: employeeEmail,
      from: FROM_EMAIL,
      subject: "SamosaMan Account Approved",
    };

    // Use dynamic template if configured, otherwise fall back to plain text/HTML
    if (SG_TEMPLATE_APPROVAL) {
      msg.templateId = SG_TEMPLATE_APPROVAL;
      msg.dynamicTemplateData = {
        employeeName,
        appUrl: APP_URL,
        loginUrl: `${APP_URL}/login`,
      };
    } else {
      msg.text = `Hello ${employeeName},\n\nYour SamosaMan employee account has been approved by the admin. You can now log in to the system.\n\nBest regards,\nSamosaMan Admin Team`;
      msg.html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #27657D;">Account Approved!</h2>
          <p>Hello ${employeeName},</p>
          <p>Your <strong>SamosaMan</strong> employee account has been approved by the admin.</p>
          <p>You can now log in to the system and start managing daily reports.</p>
          <br>
          <p>Best regards,<br>SamosaMan Admin Team</p>
        </div>
      `;
    }

    await sgMail.send(msg);
    console.log(`Approval email sent to ${employeeEmail} using ${SG_TEMPLATE_APPROVAL ? 'template' : 'HTML'}`);
    return true;
  } catch (error: any) {
    console.error("Error sending approval email:", error.response?.body || error.message);
    return false;
  }
}

export async function sendReportNotification(
  employeeName: string,
  marketName: string,
  reportDate: string,
  status: string
) {
  if (!SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured. Skipping email send.");
    return false;
  }

  try {
    const isDraft = status !== "submitted";
    const templateId = isDraft ? SG_TEMPLATE_DRAFT_SAVED : SG_TEMPLATE_REPORT_SUBMITTED;
    const actionText = isDraft ? "saved as draft" : "submitted";
    
    const msg: any = {
      to: ADMIN_EMAIL,
      from: FROM_EMAIL,
      subject: `SamosaMan Report ${isDraft ? "Draft Saved" : "Submitted"} - ${marketName}`,
    };

    // Use dynamic template if configured, otherwise fall back to plain text/HTML
    if (templateId) {
      msg.templateId = templateId;
      msg.dynamicTemplateData = {
        employeeName,
        marketName,
        reportDate,
        status: isDraft ? "Draft" : "Submitted",
        dashboardUrl: `${APP_URL}/admin`,
      };
    } else {
      msg.text = `Employee ${employeeName} has ${actionText} a report for ${marketName} on ${reportDate}.`;
      msg.html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: ${isDraft ? "#D97706" : "#27657D"};">Report ${isDraft ? "Draft Saved" : "Submitted"}!</h2>
          <p>Employee <strong>${employeeName}</strong> has ${actionText} a report.</p>
          <div style="background-color: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 5px 0;"><strong>Market:</strong> ${marketName}</p>
            <p style="margin: 5px 0;"><strong>Date:</strong> ${reportDate}</p>
            <p style="margin: 5px 0;"><strong>Status:</strong> ${isDraft ? "Draft" : "Submitted"}</p>
          </div>
          <p>Please check the admin dashboard for more details.</p>
          <br>
          <p>Best regards,<br>SamosaMan System</p>
        </div>
      `;
    }

    await sgMail.send(msg);
    console.log(`Report notification sent to admin for ${marketName} report by ${employeeName} using ${templateId ? 'template' : 'HTML'}`);
    return true;
  } catch (error: any) {
    console.error("Error sending report notification:", error.response?.body || error.message);
    return false;
  }
}

export async function sendInventoryAlert(lowStockItems: { type: string; current: number; threshold: number }[]) {
  if (!SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured. Skipping email send.");
    return false;
  }

  if (lowStockItems.length === 0) {
    return false;
  }

  try {
    const msg: any = {
      to: ADMIN_EMAIL,
      from: FROM_EMAIL,
      subject: `🚨 SamosaMan Inventory Alert - Low Stock Warning`,
    };

    // Use dynamic template if configured, otherwise fall back to plain text/HTML
    if (SG_TEMPLATE_LOW_INV) {
      msg.templateId = SG_TEMPLATE_LOW_INV;
      msg.dynamicTemplateData = {
        inventoryList: lowStockItems.map(item => ({
          type: item.type,
          current: item.current,
          threshold: item.threshold,
        })),
        dashboardUrl: `${APP_URL}/admin`,
      };
    } else {
      const itemsList = lowStockItems
        .map(item => `<li><strong>${item.type}:</strong> ${item.current} (threshold: ${item.threshold})</li>`)
        .join('');

      msg.text = `INVENTORY ALERT: The following items are below their minimum threshold:\n\n${lowStockItems.map(i => `${i.type}: ${i.current} (threshold: ${i.threshold})`).join('\n')}`;
      msg.html = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #DC2626;">🚨 Inventory Alert - Low Stock Warning</h2>
          <p>The following samosa types have fallen below their minimum inventory threshold:</p>
          <div style="background-color: #FEE2E2; padding: 15px; border-left: 4px solid #DC2626; margin: 20px 0;">
            <ul style="margin: 10px 0; padding-left: 20px;">
              ${itemsList}
            </ul>
          </div>
          <p><strong>Action Required:</strong> Please restock these items as soon as possible to avoid running out.</p>
          <br>
          <p>Best regards,<br>SamosaMan Inventory System</p>
        </div>
      `;
    }

    await sgMail.send(msg);
    console.log(`Inventory alert sent to admin for ${lowStockItems.length} low stock items using ${SG_TEMPLATE_LOW_INV ? 'template' : 'HTML'}`);
    return true;
  } catch (error: any) {
    console.error("Error sending inventory alert:", error.response?.body || error.message);
    return false;
  }
}

// Debug function to send test email
export async function sendTestEmail(testEmail?: string) {
  const recipient = testEmail || ADMIN_EMAIL;
  
  if (!SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured. Cannot send test email.");
    return { success: false, error: "SendGrid API key not configured" };
  }

  try {
    await sendWelcomeEmail(recipient, "Test Employee", "testuser123");
    return { 
      success: true, 
      message: `Test welcome email sent to ${recipient}`,
      usingTemplate: !!SG_TEMPLATE_WELCOME 
    };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.response?.body || error.message 
    };
  }
}
