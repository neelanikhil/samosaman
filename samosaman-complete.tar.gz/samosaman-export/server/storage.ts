import { type User, type InsertUser, type DailyReport, type InsertDailyReport, type Inventory, type InsertInventory, type Market, type InsertMarket, type EmployeePermission, type InsertEmployeePermission, users, dailyReports, inventory, markets, employeePermissions } from "@shared/schema";
import { randomUUID } from "crypto";
import { writeFileSync, readFileSync, existsSync } from "fs";
import { join } from "path";
import { neon } from "@neondatabase/serverless";
import { drizzle } from "drizzle-orm/neon-http";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getPendingEmployees(): Promise<User[]>;
  getAllEmployees(): Promise<User[]>;
  createReport(report: InsertDailyReport): Promise<DailyReport>;
  updateReport(id: string, report: Partial<InsertDailyReport>): Promise<DailyReport | undefined>;
  getReports(): Promise<DailyReport[]>;
  getReportById(id: string): Promise<DailyReport | undefined>;
  getInventory(): Promise<Inventory[]>;
  getInventoryBySamosaType(samosaType: string): Promise<Inventory | undefined>;
  addInventory(samosaType: string, quantity: number): Promise<Inventory>;
  updateInventoryDeductions(samosaType: string, deductions: { sold?: number; gift?: number; waste?: number; eat?: number }): Promise<Inventory | undefined>;
  getMarkets(): Promise<Market[]>;
  createMarket(market: InsertMarket): Promise<Market>;
  getMarketByName(name: string): Promise<Market | undefined>;
  createEmployeePermission(permission: InsertEmployeePermission): Promise<EmployeePermission>;
  updateEmployeePermission(employeeId: string, updates: Partial<InsertEmployeePermission>): Promise<EmployeePermission | undefined>;
  getEmployeePermission(employeeId: string): Promise<EmployeePermission | undefined>;
}

const STORAGE_FILE = join(process.cwd(), '.storage-data.json');

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private reports: Map<string, DailyReport>;
  private inventory: Map<string, Inventory>;
  private markets: Map<string, Market>;

  constructor() {
    this.users = new Map();
    this.reports = new Map();
    this.inventory = new Map();
    this.markets = new Map();
    this.loadFromFile();
  }

  private loadFromFile() {
    try {
      if (existsSync(STORAGE_FILE)) {
        const data = JSON.parse(readFileSync(STORAGE_FILE, 'utf-8'));
        
        // Load users
        if (data.users) {
          data.users.forEach((user: User) => {
            this.users.set(user.id, user);
          });
        }
        
        // Load reports with date conversion
        if (data.reports) {
          data.reports.forEach((report: any) => {
            this.reports.set(report.id, {
              ...report,
              createdAt: new Date(report.createdAt),
              updatedAt: new Date(report.updatedAt),
            });
          });
        }

        // Load inventory with date conversion
        if (data.inventory) {
          data.inventory.forEach((inv: any) => {
            this.inventory.set(inv.samosaType, {
              ...inv,
              updatedAt: new Date(inv.updatedAt),
            });
          });
        }

        // Load markets with date conversion
        if (data.markets) {
          data.markets.forEach((market: any) => {
            this.markets.set(market.id, {
              ...market,
              createdAt: new Date(market.createdAt),
            });
          });
        }
        
        console.log(`Loaded ${this.users.size} users, ${this.reports.size} reports, ${this.inventory.size} inventory items, ${this.markets.size} markets from storage`);
      }
    } catch (error) {
      console.error('Error loading storage file:', error);
    }
  }

  private saveToFile() {
    try {
      const data = {
        users: Array.from(this.users.values()),
        reports: Array.from(this.reports.values()),
        inventory: Array.from(this.inventory.values()),
        markets: Array.from(this.markets.values()),
      };
      writeFileSync(STORAGE_FILE, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Error saving storage file:', error);
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...updates };
    this.users.set(id, updatedUser);
    this.saveToFile();
    return updatedUser;
  }

  async getPendingEmployees(): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === "employee" && !user.isActive
    );
  }

  async getAllEmployees(): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.role === "employee"
    ).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async deleteUser(id: string): Promise<boolean> {
    // Note: MemStorage doesn't support employee permissions
    // In production, PgStorage handles cascade deletion of permissions
    const deleted = this.users.delete(id);
    if (deleted) {
      this.saveToFile();
    }
    return deleted;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      name: insertUser.name || null,
      email: insertUser.email || null,
      role: insertUser.role || "employee",
      isActive: insertUser.isActive ?? false,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    this.saveToFile();
    return user;
  }

  async createReport(insertReport: InsertDailyReport): Promise<DailyReport> {
    const id = randomUUID();
    const now = new Date();
    const report: DailyReport = {
      ...insertReport,
      id,
      createdAt: now,
      updatedAt: now,
      status: insertReport.status || "submitted",
      day: insertReport.day ?? null,
      shiftStart: insertReport.shiftStart ?? null,
      shiftEnd: insertReport.shiftEnd ?? null,
      samosaData: insertReport.samosaData ?? null,
      additionalItems: insertReport.additionalItems ?? null,
      fullMealsQty: insertReport.fullMealsQty ?? null,
      fullMealPrice: insertReport.fullMealPrice ?? null,
      halfMealsQty: insertReport.halfMealsQty ?? null,
      halfMealPrice: insertReport.halfMealPrice ?? null,
      expenses: insertReport.expenses ?? null,
      cashSales: insertReport.cashSales ?? null,
      mobileSales: insertReport.mobileSales ?? null,
      venmoSales: insertReport.venmoSales ?? null,
      tipsOnline: insertReport.tipsOnline ?? null,
      tipsOffline: insertReport.tipsOffline ?? null,
      totalSamosaSales: insertReport.totalSamosaSales ?? null,
      totalMealsSales: insertReport.totalMealsSales ?? null,
      totalSales: insertReport.totalSales ?? null,
      totalAmount: insertReport.totalAmount ?? null,
      difference: insertReport.difference ?? null,
      ccmTaken: insertReport.ccmTaken ?? null,
      ccmReturn: insertReport.ccmReturn ?? null,
      cpmTaken: insertReport.cpmTaken ?? null,
      cpmReturn: insertReport.cpmReturn ?? null,
      riceTaken: insertReport.riceTaken ?? null,
      riceReturn: insertReport.riceReturn ?? null,
      sssTaken: insertReport.sssTaken ?? null,
      sssReturn: insertReport.sssReturn ?? null,
      note: insertReport.note ?? null,
    };
    this.reports.set(id, report);
    this.saveToFile();
    return report;
  }

  async getReports(): Promise<DailyReport[]> {
    return Array.from(this.reports.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getReportById(id: string): Promise<DailyReport | undefined> {
    return this.reports.get(id);
  }

  async updateReport(id: string, updateData: Partial<InsertDailyReport>): Promise<DailyReport | undefined> {
    const report = this.reports.get(id);
    if (!report) return undefined;
    
    const updatedReport: DailyReport = {
      ...report,
      ...updateData,
      updatedAt: new Date(),
    };
    this.reports.set(id, updatedReport);
    this.saveToFile();
    return updatedReport;
  }

  async getInventory(): Promise<Inventory[]> {
    return Array.from(this.inventory.values());
  }

  async getInventoryBySamosaType(samosaType: string): Promise<Inventory | undefined> {
    return this.inventory.get(samosaType);
  }

  async addInventory(samosaType: string, quantity: number): Promise<Inventory> {
    const existing = this.inventory.get(samosaType);
    const now = new Date();
    
    if (existing) {
      const updated: Inventory = {
        ...existing,
        initialQuantity: existing.initialQuantity + quantity,
        updatedAt: now,
      };
      this.inventory.set(samosaType, updated);
      this.saveToFile();
      return updated;
    } else {
      const id = randomUUID();
      const newInventory: Inventory = {
        id,
        samosaType,
        initialQuantity: quantity,
        sold: 0,
        gift: 0,
        waste: 0,
        eat: 0,
        updatedAt: now,
      };
      this.inventory.set(samosaType, newInventory);
      this.saveToFile();
      return newInventory;
    }
  }

  async updateInventoryDeductions(
    samosaType: string,
    deductions: { sold?: number; gift?: number; waste?: number; eat?: number }
  ): Promise<Inventory | undefined> {
    const existing = this.inventory.get(samosaType);
    if (!existing) return undefined;

    const updated: Inventory = {
      ...existing,
      sold: existing.sold + (deductions.sold || 0),
      gift: existing.gift + (deductions.gift || 0),
      waste: existing.waste + (deductions.waste || 0),
      eat: existing.eat + (deductions.eat || 0),
      updatedAt: new Date(),
    };
    this.inventory.set(samosaType, updated);
    this.saveToFile();
    return updated;
  }

  async getMarkets(): Promise<Market[]> {
    return Array.from(this.markets.values()).sort(
      (a, b) => a.name.localeCompare(b.name)
    );
  }

  async createMarket(insertMarket: InsertMarket): Promise<Market> {
    const id = randomUUID();
    const market: Market = {
      ...insertMarket,
      id,
      createdAt: new Date(),
    };
    this.markets.set(id, market);
    this.saveToFile();
    return market;
  }

  async getMarketByName(name: string): Promise<Market | undefined> {
    return Array.from(this.markets.values()).find(
      (market) => market.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createEmployeePermission(permission: InsertEmployeePermission): Promise<EmployeePermission> {
    throw new Error("Employee permissions not supported in MemStorage");
  }

  async updateEmployeePermission(employeeId: string, updates: Partial<InsertEmployeePermission>): Promise<EmployeePermission | undefined> {
    throw new Error("Employee permissions not supported in MemStorage");
  }

  async getEmployeePermission(employeeId: string): Promise<EmployeePermission | undefined> {
    throw new Error("Employee permissions not supported in MemStorage");
  }
}

export class PgStorage implements IStorage {
  private db;

  constructor() {
    const databaseUrl = process.env.DATABASE_URL;
    if (!databaseUrl) {
      throw new Error("DATABASE_URL environment variable is not set");
    }
    const sqlClient = neon(databaseUrl);
    this.db = drizzle(sqlClient);
  }

  async getUser(id: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await this.db.select().from(users).where(eq(users.email, email)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await this.db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const result = await this.db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  async getPendingEmployees(): Promise<User[]> {
    return await this.db
      .select()
      .from(users)
      .where(sql`${users.role} = 'employee' AND ${users.isActive} = false`);
  }

  async getAllEmployees(): Promise<User[]> {
    return await this.db
      .select()
      .from(users)
      .where(eq(users.role, 'employee'))
      .orderBy(desc(users.createdAt));
  }

  async deleteUser(id: string): Promise<boolean> {
    try {
      // First delete employee permissions if they exist
      await this.db
        .delete(employeePermissions)
        .where(eq(employeePermissions.employeeId, id));
      
      // Then delete the user
      await this.db.delete(users).where(eq(users.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting user:", error);
      return false;
    }
  }

  async createReport(insertReport: InsertDailyReport): Promise<DailyReport> {
    const result = await this.db.insert(dailyReports).values(insertReport).returning();
    return result[0];
  }

  async updateReport(id: string, updateData: Partial<InsertDailyReport>): Promise<DailyReport | undefined> {
    const result = await this.db
      .update(dailyReports)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(dailyReports.id, id))
      .returning();
    return result[0];
  }

  async getReports(): Promise<DailyReport[]> {
    return await this.db.select().from(dailyReports).orderBy(desc(dailyReports.createdAt));
  }

  async getReportById(id: string): Promise<DailyReport | undefined> {
    const result = await this.db.select().from(dailyReports).where(eq(dailyReports.id, id)).limit(1);
    return result[0];
  }

  async getInventory(): Promise<Inventory[]> {
    return await this.db.select().from(inventory);
  }

  async getInventoryBySamosaType(samosaType: string): Promise<Inventory | undefined> {
    const result = await this.db.select().from(inventory).where(eq(inventory.samosaType, samosaType)).limit(1);
    return result[0];
  }

  async addInventory(samosaType: string, quantity: number): Promise<Inventory> {
    const existing = await this.getInventoryBySamosaType(samosaType);
    
    if (existing) {
      const result = await this.db
        .update(inventory)
        .set({
          initialQuantity: existing.initialQuantity + quantity,
          updatedAt: new Date(),
        })
        .where(eq(inventory.samosaType, samosaType))
        .returning();
      return result[0];
    } else {
      const result = await this.db
        .insert(inventory)
        .values({
          samosaType,
          initialQuantity: quantity,
          sold: 0,
          gift: 0,
          waste: 0,
          eat: 0,
        })
        .returning();
      return result[0];
    }
  }

  async updateInventoryDeductions(
    samosaType: string,
    deductions: { sold?: number; gift?: number; waste?: number; eat?: number }
  ): Promise<Inventory | undefined> {
    const existing = await this.getInventoryBySamosaType(samosaType);
    if (!existing) return undefined;

    const result = await this.db
      .update(inventory)
      .set({
        sold: existing.sold + (deductions.sold || 0),
        gift: existing.gift + (deductions.gift || 0),
        waste: existing.waste + (deductions.waste || 0),
        eat: existing.eat + (deductions.eat || 0),
        updatedAt: new Date(),
      })
      .where(eq(inventory.samosaType, samosaType))
      .returning();
    return result[0];
  }

  async getMarkets(): Promise<Market[]> {
    return await this.db.select().from(markets).orderBy(markets.name);
  }

  async createMarket(insertMarket: InsertMarket): Promise<Market> {
    const result = await this.db.insert(markets).values(insertMarket).returning();
    return result[0];
  }

  async getMarketByName(name: string): Promise<Market | undefined> {
    const result = await this.db
      .select()
      .from(markets)
      .where(sql`LOWER(${markets.name}) = LOWER(${name})`)
      .limit(1);
    return result[0];
  }

  async createEmployeePermission(permission: InsertEmployeePermission): Promise<EmployeePermission> {
    const result = await this.db.insert(employeePermissions).values(permission).returning();
    return result[0];
  }

  async updateEmployeePermission(employeeId: string, updates: Partial<InsertEmployeePermission>): Promise<EmployeePermission | undefined> {
    const result = await this.db
      .update(employeePermissions)
      .set(updates)
      .where(eq(employeePermissions.employeeId, employeeId))
      .returning();
    return result[0];
  }

  async getEmployeePermission(employeeId: string): Promise<EmployeePermission | undefined> {
    const result = await this.db
      .select()
      .from(employeePermissions)
      .where(eq(employeePermissions.employeeId, employeeId))
      .limit(1);
    return result[0];
  }
}

// Initialize default users
async function initializeDefaultUsers(storage: IStorage) {
  const adminUser = await storage.getUserByUsername("Admin");
  const employeeUser = await storage.getUserByUsername("Employee");

  if (!adminUser) {
    await storage.createUser({
      username: "Admin",
      password: "password",
      role: "admin",
    });
    console.log("Created default Admin user");
  }

  if (!employeeUser) {
    await storage.createUser({
      username: "Employee",
      password: "password",
      role: "employee",
    });
    console.log("Created default Employee user");
  }
}

// Use PostgreSQL storage for production
const storageInstance = new PgStorage();

// Initialize default users
initializeDefaultUsers(storageInstance).catch(console.error);

export const storage = storageInstance;
