import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertDailyReportSchema, insertMarketSchema, insertUserSchema, SAMOSA_TYPES, type SamosaReportData } from "@shared/schema";
import { hashPassword, comparePassword, generateToken, verifyToken, verifyAdmin, verifyRole, type AuthRequest } from "./auth";
import { sendApprovalEmail, sendWelcomeEmail, sendReportNotification, sendInventoryAlert, sendTestEmail } from "./email";

// Inventory thresholds for low stock alerts
const INVENTORY_THRESHOLDS: Record<string, number> = {
  APP: 150,
  VEG: 225,
  PJB: 225,
  VSP: 225,
  SCH: 300,
  CHC: 300,
  STC: 300,
  STP: 225,
};

// Helper function to check inventory levels and send alerts if needed
async function checkInventoryAndAlert() {
  try {
    const inventory = await storage.getInventory();
    const lowStockItems: { type: string; current: number; threshold: number }[] = [];

    for (const item of inventory) {
      const threshold = INVENTORY_THRESHOLDS[item.samosaType];
      if (threshold) {
        const currentStock = item.initialQuantity - item.sold - item.gift - item.waste - item.eat;
        if (currentStock < threshold) {
          lowStockItems.push({
            type: SAMOSA_TYPES[item.samosaType as keyof typeof SAMOSA_TYPES] || item.samosaType,
            current: currentStock,
            threshold,
          });
        }
      }
    }

    if (lowStockItems.length > 0) {
      await sendInventoryAlert(lowStockItems);
    }
  } catch (error) {
    console.error("Error checking inventory levels:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const { username, email, password, name } = req.body;

      if (!username || !email || !password) {
        return res.status(400).json({ error: "Username, email, and password are required" });
      }

      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: "Email already registered" });
      }

      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already taken" });
      }

      // Hash password
      const hashedPassword = await hashPassword(password);

      // Create user (employees start as inactive)
      const user = await storage.createUser({
        username,
        email,
        name: name || username,
        password: hashedPassword,
        role: "employee",
        isActive: false,
      });

      // Send welcome email
      await sendWelcomeEmail(email, name || username, username);

      res.json({ 
        message: "Registration successful. Awaiting admin approval.",
        userId: user.id 
      });
    } catch (error: any) {
      console.error("Signup error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }

      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Verify password
      const isValidPassword = await comparePassword(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      // Check if admin email matches
      const adminEmail = process.env.ADMIN_EMAIL;
      if (user.role === "admin" && adminEmail && user.email !== adminEmail) {
        return res.status(403).json({ error: "Access denied. Invalid admin email." });
      }

      // Check if employee is active
      if (user.role === "employee" && !user.isActive) {
        return res.status(403).json({ error: "Awaiting admin approval" });
      }

      // Generate token
      const token = generateToken({
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      });

      res.json({
        token,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          name: user.name,
          role: user.role,
        },
      });
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Admin routes
  app.get("/api/admin/pending-employees", verifyToken, verifyAdmin, async (req, res) => {
    try {
      const pendingEmployees = await storage.getPendingEmployees();
      res.json(pendingEmployees);
    } catch (error: any) {
      console.error("Error fetching pending employees:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get("/api/admin/employees", verifyToken, verifyAdmin, async (req, res) => {
    try {
      const employees = await storage.getAllEmployees();
      res.json(employees);
    } catch (error: any) {
      console.error("Error fetching employees:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.delete("/api/admin/employees/:id", verifyToken, verifyAdmin, async (req, res) => {
    try {
      const employeeId = req.params.id;
      
      const user = await storage.getUser(employeeId);
      if (!user) {
        return res.status(404).json({ error: "Employee not found" });
      }

      if (user.role !== "employee") {
        return res.status(400).json({ error: "Can only delete employee accounts" });
      }

      const deleted = await storage.deleteUser(employeeId);
      
      if (!deleted) {
        return res.status(500).json({ error: "Failed to delete employee" });
      }

      res.json({ message: "Employee deleted successfully", employeeId });
    } catch (error: any) {
      console.error("Error deleting employee:", error);
      res.status(500).json({ error: error.message });
    }
  });

  app.patch("/api/admin/approve/:id", verifyToken, verifyAdmin, async (req, res) => {
    try {
      const employeeId = req.params.id;
      
      const user = await storage.getUser(employeeId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      if (user.role !== "employee") {
        return res.status(400).json({ error: "User is not an employee" });
      }

      // Update user to active
      const updatedUser = await storage.updateUser(employeeId, { isActive: true });
      
      if (!updatedUser) {
        return res.status(500).json({ error: "Failed to update user" });
      }

      // Create/update employee permission
      const existingPermission = await storage.getEmployeePermission(employeeId);
      if (existingPermission) {
        await storage.updateEmployeePermission(employeeId, {
          approvedByAdmin: true,
          approvedDate: new Date(),
        });
      } else {
        await storage.createEmployeePermission({
          employeeId,
          approvedByAdmin: true,
          approvedDate: new Date(),
        });
      }

      // Send approval email
      if (updatedUser.email) {
        await sendApprovalEmail(updatedUser.email, updatedUser.name || updatedUser.username);
      }

      res.json({ message: "Employee approved successfully", user: updatedUser });
    } catch (error: any) {
      console.error("Error approving employee:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Submit a daily report (create or update)
  app.post("/api/reports", async (req, res) => {
    try {
      const reportData = insertDailyReportSchema.parse(req.body);
      const report = await storage.createReport(reportData);
      console.log('Report created:', report.id);
      
      // Send report notification to admin
      await sendReportNotification(
        reportData.employeeName,
        reportData.marketName,
        reportData.date,
        reportData.status || "draft"
      );
      
      // If status is submitted, update inventory deductions
      if (reportData.status === "submitted" && reportData.samosaData) {
        const samosaData = JSON.parse(reportData.samosaData);
        console.log('Processing inventory deductions for samosa data:', samosaData);
        
        for (const [samosaType, data] of Object.entries(samosaData)) {
          if (SAMOSA_TYPES[samosaType as keyof typeof SAMOSA_TYPES]) {
            const formData = data as any;
            // Calculate sold: Taken - RNF - RF - Gift - Waste - Eat
            const taken = parseFloat(formData.taken) || 0;
            const rnf = parseFloat(formData.rnf) || 0;
            const rf = parseFloat(formData.rf) || 0;
            const gift = parseFloat(formData.gift) || 0;
            const waste = parseFloat(formData.waste) || 0;
            const eat = parseFloat(formData.eat) || 0;
            
            const sold = Math.max(0, taken - rnf - rf - gift - waste - eat);
            
            console.log(`Deducting from ${samosaType}: sold=${sold}, gift=${gift}, waste=${waste}, eat=${eat}`);
            
            await storage.updateInventoryDeductions(samosaType, {
              sold,
              gift,
              waste,
              eat,
            });
          }
        }
        console.log('Inventory deductions applied successfully');
        
        // Check inventory levels and send alerts if needed
        await checkInventoryAndAlert();
      }
      
      res.json(report);
    } catch (error: any) {
      console.error('Error creating report:', error);
      res.status(400).json({ error: error.message });
    }
  });

  // Update a report
  app.patch("/api/reports/:id", async (req, res) => {
    try {
      const updateData = req.body;
      const report = await storage.updateReport(req.params.id, updateData);
      
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }

      // Send report notification to admin (for any update)
      await sendReportNotification(
        report.employeeName,
        report.marketName,
        report.date,
        report.status
      );

      // If status changed to submitted, update inventory deductions
      if (updateData.status === "submitted" && updateData.samosaData) {
        const samosaData = JSON.parse(updateData.samosaData);
        console.log('Processing inventory deductions for updated report:', samosaData);
        
        for (const [samosaType, data] of Object.entries(samosaData)) {
          if (SAMOSA_TYPES[samosaType as keyof typeof SAMOSA_TYPES]) {
            const formData = data as any;
            // Calculate sold: Taken - RNF - RF - Gift - Waste - Eat
            const taken = parseFloat(formData.taken) || 0;
            const rnf = parseFloat(formData.rnf) || 0;
            const rf = parseFloat(formData.rf) || 0;
            const gift = parseFloat(formData.gift) || 0;
            const waste = parseFloat(formData.waste) || 0;
            const eat = parseFloat(formData.eat) || 0;
            
            const sold = Math.max(0, taken - rnf - rf - gift - waste - eat);
            
            console.log(`Deducting from ${samosaType}: sold=${sold}, gift=${gift}, waste=${waste}, eat=${eat}`);
            
            await storage.updateInventoryDeductions(samosaType, {
              sold,
              gift,
              waste,
              eat,
            });
          }
        }
        console.log('Inventory deductions applied successfully on update');
        
        // Check inventory levels and send alerts if needed
        await checkInventoryAndAlert();
      }
      
      res.json(report);
    } catch (error: any) {
      console.error('Error updating report:', error);
      res.status(400).json({ error: error.message });
    }
  });

  // Get all reports
  app.get("/api/reports", async (req, res) => {
    try {
      const reports = await storage.getReports();
      console.log('Fetching reports, count:', reports.length);
      res.json(reports);
    } catch (error: any) {
      console.error('Error fetching reports:', error);
      res.status(500).json({ error: error.message });
    }
  });

  // Get a specific report by ID
  app.get("/api/reports/:id", async (req, res) => {
    try {
      const report = await storage.getReportById(req.params.id);
      if (!report) {
        return res.status(404).json({ error: "Report not found" });
      }
      res.json(report);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get inventory
  app.get("/api/inventory", async (req, res) => {
    try {
      const inventory = await storage.getInventory();
      res.json(inventory);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Add to inventory
  app.post("/api/inventory/add", async (req, res) => {
    try {
      const { inventory } = req.body;
      const results = [];
      
      for (const [samosaType, quantity] of Object.entries(inventory)) {
        if (quantity && typeof quantity === 'number' && quantity > 0) {
          const result = await storage.addInventory(samosaType, quantity);
          results.push(result);
        }
      }
      
      res.json(results);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Get markets
  app.get("/api/markets", async (req, res) => {
    try {
      const markets = await storage.getMarkets();
      res.json(markets);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Create market
  app.post("/api/markets", async (req, res) => {
    try {
      const marketData = insertMarketSchema.parse(req.body);
      
      // Check if market already exists
      const existing = await storage.getMarketByName(marketData.name);
      if (existing) {
        return res.status(400).json({ error: "Market already exists" });
      }
      
      const market = await storage.createMarket(marketData);
      res.json(market);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Get dashboard statistics
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const { period = 'weekly' } = req.query;
      const reports = await storage.getReports();
      const submittedReports = reports.filter(r => r.status === 'submitted');
      
      // Calculate date range
      const now = new Date();
      const startDate = new Date();
      if (period === 'weekly') {
        startDate.setDate(now.getDate() - 7);
      } else {
        startDate.setDate(now.getDate() - 30);
      }
      
      const periodReports = submittedReports.filter(r => 
        new Date(r.createdAt) >= startDate
      );

      // Calculate totals
      const totalRevenue = periodReports.reduce((sum, r) => 
        sum + (parseFloat(r.totalSales?.toString() || '0')), 0
      );
      
      const totalSold = periodReports.reduce((sum, r) => {
        if (!r.samosaData) return sum;
        const data = JSON.parse(r.samosaData);
        return sum + Object.values(data).reduce((s: number, d: any) => s + (d.sold || 0), 0);
      }, 0);

      // Calculate sales by samosa type
      const samosaTypeSales: Record<string, number> = {};
      periodReports.forEach(r => {
        if (!r.samosaData) return;
        const data = JSON.parse(r.samosaData);
        Object.entries(data).forEach(([type, d]: [string, any]) => {
          samosaTypeSales[type] = (samosaTypeSales[type] || 0) + (d.sold || 0);
        });
      });

      // Calculate sales by market
      const marketSales: Record<string, { revenue: number; samosas: number }> = {};
      periodReports.forEach(r => {
        const market = r.marketName;
        if (!marketSales[market]) {
          marketSales[market] = { revenue: 0, samosas: 0 };
        }
        marketSales[market].revenue += parseFloat(r.totalSales?.toString() || '0');
        
        if (r.samosaData) {
          const data = JSON.parse(r.samosaData);
          marketSales[market].samosas += Object.values(data).reduce((s: number, d: any) => s + (d.sold || 0), 0);
        }
      });

      // Find top seller and top market
      const topSeller = Object.entries(samosaTypeSales).sort((a, b) => b[1] - a[1])[0];
      const topMarket = Object.entries(marketSales).sort((a, b) => b[1].revenue - a[1].revenue)[0];

      res.json({
        totalRevenue,
        totalSold,
        topSeller: topSeller ? { type: topSeller[0], sold: topSeller[1] } : null,
        topMarket: topMarket ? { name: topMarket[0], revenue: topMarket[1].revenue } : null,
        samosaTypeSales: Object.entries(samosaTypeSales).map(([name, value]) => ({ name, value })),
        marketSales: Object.entries(marketSales).map(([market, data]) => ({ 
          market, 
          revenue: data.revenue,
          samosas: data.samosas 
        })),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Get dashboard data with date filtering
  app.get("/api/dashboard-data", async (req, res) => {
    try {
      const { startDate, endDate } = req.query;
      const reports = await storage.getReports();
      const submittedReports = reports.filter(r => r.status === 'submitted');
      
      // Filter by date range if provided
      let periodReports = submittedReports;
      if (startDate && endDate) {
        const start = new Date(startDate as string);
        const end = new Date(endDate as string);
        end.setHours(23, 59, 59, 999); // Include the entire end day
        
        periodReports = submittedReports.filter(r => {
          // Use 'date' field instead of 'reportDate'
          const reportDate = new Date(r.date);
          return reportDate >= start && reportDate <= end;
        });
      }

      // Calculate total revenue: (cash + mobile + venmo) - expenses (NO TIPS)
      const totalRevenue = periodReports.reduce((sum, r) => {
        const cash = parseFloat(r.cashSales?.toString() || '0');
        const mobile = parseFloat(r.mobileSales?.toString() || '0');
        const venmo = parseFloat(r.venmoSales?.toString() || '0');
        const expenses = parseFloat(r.expenses?.toString() || '0');
        return sum + (cash + mobile + venmo - expenses);
      }, 0);
      
      // Calculate total samosas sold
      const totalSold = periodReports.reduce((sum, r) => {
        if (!r.samosaData) return sum;
        const data = JSON.parse(r.samosaData);
        return sum + Object.values(data).reduce((s: number, d: any) => {
          const taken = parseFloat(d.taken) || 0;
          const rnf = parseFloat(d.rnf) || 0;
          const rf = parseFloat(d.rf) || 0;
          const gift = parseFloat(d.gift) || 0;
          const waste = parseFloat(d.waste) || 0;
          const eat = parseFloat(d.eat) || 0;
          return s + Math.max(0, taken - rnf - rf - gift - waste - eat);
        }, 0);
      }, 0);

      // Calculate sales by samosa type (for pie chart)
      const samosaTypeSales: Record<string, number> = {};
      periodReports.forEach(r => {
        if (!r.samosaData) return;
        const data = JSON.parse(r.samosaData);
        Object.entries(data).forEach(([type, d]: [string, any]) => {
          const taken = parseFloat(d.taken) || 0;
          const rnf = parseFloat(d.rnf) || 0;
          const rf = parseFloat(d.rf) || 0;
          const gift = parseFloat(d.gift) || 0;
          const waste = parseFloat(d.waste) || 0;
          const eat = parseFloat(d.eat) || 0;
          const sold = Math.max(0, taken - rnf - rf - gift - waste - eat);
          samosaTypeSales[type] = (samosaTypeSales[type] || 0) + sold;
        });
      });

      // Calculate sales by market (for bar chart) with revenue and date info
      const marketSales: Record<string, { revenue: number; samosas: number; date: string; day: string }> = {};
      periodReports.forEach(r => {
        const market = r.marketName;
        if (!marketSales[market]) {
          marketSales[market] = { revenue: 0, samosas: 0, date: r.date || '', day: r.day || '' };
        }
        
        // Add revenue (cash + mobile + venmo - expenses)
        const cash = parseFloat(r.cashSales?.toString() || '0');
        const mobile = parseFloat(r.mobileSales?.toString() || '0');
        const venmo = parseFloat(r.venmoSales?.toString() || '0');
        const expenses = parseFloat(r.expenses?.toString() || '0');
        marketSales[market].revenue += (cash + mobile + venmo - expenses);
        
        // Track the most recent date and day
        if (r.date && r.date > marketSales[market].date) {
          marketSales[market].date = r.date;
          marketSales[market].day = r.day || '';
        }
        
        if (r.samosaData) {
          const data = JSON.parse(r.samosaData);
          const marketTotal = Object.values(data).reduce((s: number, d: any) => {
            const taken = parseFloat(d.taken) || 0;
            const rnf = parseFloat(d.rnf) || 0;
            const rf = parseFloat(d.rf) || 0;
            const gift = parseFloat(d.gift) || 0;
            const waste = parseFloat(d.waste) || 0;
            const eat = parseFloat(d.eat) || 0;
            return s + Math.max(0, taken - rnf - rf - gift - waste - eat);
          }, 0);
          marketSales[market].samosas += marketTotal;
        }
      });

      // Find top market by samosas sold
      const topMarketEntry = Object.entries(marketSales).sort((a, b) => b[1].samosas - a[1].samosas)[0];
      const topMarket = topMarketEntry ? { name: topMarketEntry[0], samosas: topMarketEntry[1].samosas } : null;

      res.json({
        totalRevenue,
        totalSold,
        topMarket,
        samosaTypeSales: Object.entries(samosaTypeSales)
          .filter(([name, value]) => value > 0 && name !== 'CCM' && name !== 'CPM') // Filter out CCM, CPM and 0 values
          .map(([name, value]) => ({ 
            name, 
            value 
          })),
        marketSales: Object.entries(marketSales).map(([name, data]) => ({ 
          name, 
          revenue: data.revenue,
          samosas: data.samosas,
          date: data.date,
          day: data.day
        })),
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Debug endpoint to test email sending (admin only)
  app.get("/api/debug/send-test-email", verifyToken, verifyAdmin, async (req: AuthRequest, res) => {
    try {
      // Only allow sending to admin email for security
      const result = await sendTestEmail();
      
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        success: false, 
        error: error.message 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
